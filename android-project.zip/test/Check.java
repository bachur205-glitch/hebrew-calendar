package com.example.hebrewcalendar;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;

public class Check {
    static int bad = 0;
    static void ok(boolean c, String m) { if (!c) { bad++; System.out.println("FAIL " + m); } else System.out.println("ok   " + m); }
    static int rd(int y, int m, int d) { return HebCal.gregToRD(y, m, d); }
    static Model fresh() { return new Model(rd(2026, 11, 3), new EventStore()); }
    static final java.util.Set<String> NEW = new java.util.HashSet<String>(java.util.Arrays.asList("erev_rh","erev_yk","erev_sukkot","erev_pesach","bechorim","pesach_sheni","erev_shavuot","erev_tisha","omer"));
    static java.util.List<String> keysOn(int y, String id, int d, int wd, boolean isr, boolean ch) {
        java.util.List<String> o = new java.util.ArrayList<String>();
        for (HebCal.Hol x : HebCal.holidays(y, id, d, wd, isr, ch)) o.add(x.k + (x.n > 0 ? ":" + x.n : ""));
        return o;
    }
    static void keys(Model m, int... ks) { for (int k : ks) m.key(k); }

    public static void main(String[] a) throws Exception {
        TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));

        // 1) engine vs the JS engine (which was verified against Intl)
        int n = 0, mism = 0;
        for (String line : Files.readAllLines(Paths.get(a[0]))) {
            String[] p = line.split(" ", -1);
            int r = Integer.parseInt(p[0]);
            HebCal.HDate h = HebCal.rdToHeb(r);
            HebCal.GDate g = HebCal.rdToGreg(r);
            StringBuilder hk = new StringBuilder();
            for (HebCal.Hol x : HebCal.holidays(h.y, h.id, h.d, HebCal.dow(r), false, false)) if (!NEW.contains(x.k)) hk.append(x.k).append(x.n > 0 ? ":" + x.n : "").append(',');
            String mine = r + " " + h.y + " " + h.id + " " + h.d + " " + HebCal.dow(r) + " " + g.y + "-" + g.m + "-" + g.d + " " + hk;
            n++;
            if (!mine.equals(line) || HebCal.hebToRD(h.y, h.id, h.d) != r) { if (mism++ < 5) System.out.println("DIFF\n " + mine + "\n " + line); }
        }
        ok(mism == 0, n + " days identical to JS engine (" + mism + " mismatches)");


        // 1b) new holidays and Chabad days
        ok(keysOn(5787, "Elul", 29, 0, false, true).containsAll(java.util.Arrays.asList("erev_rh", "c_tzemach_birth")), "29 Elul: Erev RH + Chabad");
        ok(!keysOn(5787, "Elul", 29, 0, false, false).contains("c_tzemach_birth"), "Chabad off hides Chabad days");
        ok(keysOn(5787, "Nisan", 16, 0, false, false).contains("omer:1") && keysOn(5787, "Iyar", 18, 0, false, false).contains("omer:33"), "Omer 1 on 16 Nisan, 33 on Lag BaOmer");
        ok(keysOn(5787, "Sivan", 5, 0, false, false).contains("omer:49") && !keysOn(5787, "Sivan", 6, 0, false, false).contains("omer:50"), "Omer ends at 49");
        ok(keysOn(5787, "Sivan", 6, 0, false, true).contains("c_baal_shem_tov"), "Baal Shem Tov yahrzeit on Shavuot");
        ok(keysOn(5787, "Tammuz", 3, 0, false, true).contains("c_gimmel_tammuz") && keysOn(5787, "Kislev", 19, 0, false, true).contains("c_yud_tes_kislev"), "3 Tammuz and 19 Kislev");
        ok(keysOn(5787, "Iyar", 14, 0, false, false).contains("pesach_sheni"), "Pesach Sheni");
        ok(keysOn(5787, "Nisan", 14, 1, false, false).contains("bechorim") && keysOn(5787, "Nisan", 12, 4, false, false).contains("bechorim") && !keysOn(5787, "Nisan", 14, 6, false, false).contains("bechorim"), "Fast of Firstborn (moved when Erev Pesach is Shabbat)");
        ok(keysOn(5787, "Nisan", 16, 0, true, false).contains("chm") && !keysOn(5787, "Nisan", 16, 0, true, false).contains("pesach2"), "Israel: 16 Nisan is Chol HaMoed");
        int bad = 0;
        for (int r = HebCal.hebToRD(5780, "Tishri", 1); r < HebCal.hebToRD(5800, "Tishri", 1); r++) {
            HebCal.HDate hh = HebCal.rdToHeb(r);
            for (HebCal.Hol x : HebCal.holidays(hh.y, hh.id, hh.d, HebCal.dow(r), false, true)) if (x.k.contains("atzmaut") || x.k.contains("yerushalayim") || x.k.contains("hashoah")) bad++;
        }
        ok(bad == 0, "no Zionist/state days");

        // 2) calendar keys (unchanged behaviour)
        Model m = fresh();
        ok(m.y == 5787 && m.id.equals("Cheshvan") && m.sel == 23, "starts at 23 Cheshvan 5787");
        keys(m, Model.RIGHT); ok(m.id.equals("Kislev"), "Right -> Kislev");
        keys(m, Model.LEFT, Model.LEFT); ok(m.id.equals("Tishri"), "Left x2 -> Tishri");
        keys(m, Model.LEFT); ok(m.id.equals("Elul") && m.y == 5786, "Left -> Elul 5786");
        keys(m, Model.RIGHT, Model.UP); ok(m.y == 5788, "Up -> next year");
        keys(m, Model.DOWN, Model.DOWN); ok(m.y == 5786, "Down x2 -> 5786");
        ok(!fresh().key(Model.BACK), "Back on the month view = exit app");
        m = fresh();
        keys(m, Model.OK); ok(m.mode == Model.M_DAY, "OK enters day cursor");
        keys(m, Model.RIGHT); ok(m.sel == 24, "Right -> 24");
        keys(m, Model.UP); ok(m.sel == 17, "Up -> 17");
        keys(m, Model.DOWN, Model.DOWN, Model.DOWN, Model.DOWN);
        ok(m.id.equals("Kislev") && m.view == Model.V_CAL, "Down keeps going into the next month (" + m.id + " " + m.sel + ")");

        // 3) right soft key opens the menu; items work
        m = fresh();
        keys(m, Model.SOFTR); ok(m.menuOpen, "right soft key opens the menu");
        keys(m, Model.RIGHT, Model.UP, Model.DOWN); ok(m.menuOpen && m.menuIdx == 0, "arrows inside menu do not move the calendar");
        ok(m.id.equals("Cheshvan"), "calendar untouched while menu open");
        keys(m, Model.BACK); ok(!m.menuOpen && m.view == Model.V_CAL, "Back closes the menu");
        keys(m, Model.RIGHT); keys(m, Model.SOFTR, Model.OK);
        ok(m.id.equals("Cheshvan") && m.sel == 23 && m.mode == Model.M_DAY, "menu > Today jumps to today");
        keys(m, Model.SOFTR, Model.DOWN, Model.DOWN, Model.OK); ok(m.view == Model.V_UP, "menu > Upcoming events");
        keys(m, Model.BACK); keys(m, Model.SOFTR, Model.DOWN, Model.DOWN, Model.DOWN, Model.OK); ok(m.view == Model.V_CONV, "menu > Convert");
        keys(m, Model.SOFTR); ok(m.view == Model.V_CAL, "right soft key = Back in converter");
        keys(m, Model.SOFTR, Model.UP, Model.OK); ok(m.view == Model.V_SET, "menu (wrap up) > Settings");
        keys(m, Model.OK); ok(m.he, "settings: OK switches to Hebrew");
        keys(m, Model.DOWN, Model.DOWN); ok(m.chabad, "Chabad default on"); keys(m, Model.OK); ok(!m.chabad, "settings: third row toggles Chabad days"); keys(m, Model.OK);
        keys(m, Model.DOWN, Model.DOWN, Model.DOWN); ok(m.setIdx == 3, "settings has 4 rows"); keys(m, Model.UP, Model.UP, Model.UP);
        keys(m, Model.BACK);
        ok(m.softR().equals("תפריט"), "soft key labels follow language");
        ok(Model.monthName("Adar", true).length() > 0, "month names");

        // 4) events: add, edit, reminder, delete
        m = fresh();
        keys(m, Model.OK);                           // cursor on today (23 Cheshvan)
        keys(m, Model.SOFTL);                         // left soft key = add event
        ok(m.view == Model.V_EDIT && m.editNew, "left soft key opens the new-event editor");
        m.setTitle("Dentist");
        keys(m, Model.DOWN, Model.RIGHT);             // time row: all day -> 09:00
        ok(m.edit.minutes == 540, "time: Right from all-day = 09:00");
        keys(m, Model.RIGHT, Model.RIGHT); ok(m.edit.minutes == 570, "time: +15 min steps");
        keys(m, Model.DOWN, Model.RIGHT, Model.RIGHT); ok(m.edit.remind == 5, "reminder cycles: none > at time > 5 min");
        keys(m, Model.DOWN, Model.RIGHT); ok(m.edit.yearly, "repeat toggles to yearly");
        keys(m, Model.SOFTL);
        ok(m.view == Model.V_DAY && m.dayEvents().size() == 1 && m.dayEvents().get(0).title.equals("Dentist"), "Save returns to the day with the event");
        ok(m.store.any(rd(2026, 11, 3)) && !m.store.any(rd(2026, 11, 4)), "event shows on its day only");
        keys(m, Model.RIGHT); ok(m.sel == 24 && m.dayEvents().isEmpty(), "Right in day screen = next day");
        keys(m, Model.LEFT); ok(m.sel == 23, "Left = previous day");
        // edit
        keys(m, Model.OK); ok(m.view == Model.V_EDIT && !m.editNew && m.edit.title.equals("Dentist"), "OK on event opens it");
        m.setTitle("Dentist (moved)"); keys(m, Model.SOFTL);
        ok(m.dayEvents().size() == 1 && m.dayEvents().get(0).title.equals("Dentist (moved)"), "edit saved in place");
        // cancel
        keys(m, Model.OK, Model.SOFTR); ok(m.view == Model.V_DAY, "Cancel returns without saving");
        // add row
        keys(m, Model.DOWN); keys(m, Model.OK); ok(m.view == Model.V_EDIT && m.editNew, "'+ Add event' row opens the editor");
        keys(m, Model.BACK); ok(m.view == Model.V_DAY, "Back from editor returns to day");
        // delete needs a confirmation
        keys(m, Model.UP, Model.SOFTR); ok(m.dayEvents().size() == 1 && m.softR().equals("Sure?"), "first Delete press asks 'Sure?'");
        keys(m, Model.SOFTR); ok(m.dayEvents().isEmpty(), "second press deletes");
        keys(m, Model.BACK); ok(m.view == Model.V_CAL && m.mode == Model.M_DAY, "Back returns to the calendar");
        // untitled event gets a default title
        keys(m, Model.SOFTL, Model.SOFTL); ok(m.dayEvents().get(0).title.equals("Event"), "empty title -> 'Event'");

        // 5) yearly Hebrew-date repeat (birthday / yahrzeit)
        EventStore s = new EventStore();
        EventStore.Event e = s.create(rd(2026, 11, 3)); e.title = "Birthday"; e.yearly = true; s.save(e); // 23 Cheshvan 5787
        int next = HebCal.hebToRD(5788, "Cheshvan", 23);
        ok(s.on(next).size() == 1 && !s.any(next + 1), "yearly event recurs on 23 Cheshvan 5788 (" + HebCal.rdToGreg(next).y + "-" + HebCal.rdToGreg(next).m + "-" + HebCal.rdToGreg(next).d + ")");
        ok(!s.any(rd(2026, 11, 3) - 365), "not before its first date");
        EventStore.Event adar = s.create(HebCal.hebToRD(5787, "AdarII", 10)); adar.yearly = true; s.save(adar); // leap year
        ok(s.any(HebCal.hebToRD(5788, "Adar", 10)), "Adar II birthday falls in plain Adar the next (non-leap) year");

        // 6) reminders
        EventStore.Event r = s.create(rd(2026, 12, 25)); r.minutes = 9 * 60; r.remind = 30; s.save(r);
        java.util.Calendar c = java.util.Calendar.getInstance(); c.clear(); c.set(2026, 11, 25, 8, 30, 0);
        ok(EventStore.triggerAt(r, r.rd) == c.getTimeInMillis(), "09:00 event with 30-min reminder fires at 08:30");
        EventStore.Event ad = s.create(rd(2026, 12, 25)); ad.remind = 1440; s.save(ad);
        c.clear(); c.set(2026, 11, 24, 9, 0, 0);
        ok(EventStore.triggerAt(ad, ad.rd) == c.getTimeInMillis(), "all-day event, 1 day before = 09:00 the day before");
        long now = EventStore.triggerAt(r, r.rd) + 1;
        ok(s.nextTrigger(r, rd(2026, 12, 25), now) == null, "a one-time reminder in the past does not fire again");
        EventStore.Trigger t = s.nextTrigger(e, rd(2026, 11, 3), 0); // e has no reminder
        ok(t == null, "no reminder set -> no trigger");
        e.remind = 0; e.minutes = 8 * 60; s.save(e);
        long afterFirst = EventStore.triggerAt(e, e.rd) + 1000;
        t = s.nextTrigger(e, e.rd, afterFirst);
        ok(t != null && t.rd == next, "yearly reminder rolls to the next Hebrew-date occurrence");

        // 7) storage round trip (titles with separators)
        EventStore st = new EventStore();
        EventStore.Event w = st.create(rd(2027, 1, 2)); w.title = "A|B\\C\nline2 שלום"; w.minutes = 615; w.remind = 60; w.yearly = true; st.save(w);
        EventStore st2 = new EventStore(); st2.decode(st.encode());
        ok(st2.list.size() == 1 && st2.list.get(0).title.equals(w.title) && st2.list.get(0).minutes == 615 && st2.list.get(0).yearly
                && st2.list.get(0).remind == 60 && st2.list.get(0).id == w.id, "encode/decode round trip");
        st2.decode("garbage\n1|2|3\n"); ok(st2.list.isEmpty(), "damaged data is ignored, no crash");

        // 8) upcoming list + intents
        m = fresh();
        EventStore.Event u1 = m.store.create(rd(2026, 11, 20)); u1.title = "Later"; m.store.save(u1);
        EventStore.Event u2 = m.store.create(rd(2026, 11, 5)); u2.title = "Sooner"; m.store.save(u2);
        EventStore.Event past = m.store.create(rd(2026, 10, 1)); past.title = "Past"; m.store.save(past);
        m.openUpcoming();
        ok(m.up.size() == 2 && m.up.get(0).e.title.equals("Sooner") && m.up.get(1).e.title.equals("Later"), "upcoming: sorted, past events hidden");
        keys(m, Model.DOWN, Model.OK); ok(m.view == Model.V_DAY && m.dayEvents().get(m.dayIdx).title.equals("Later"), "OK opens that day on that event");
        m.newEventFor(rd(2027, 3, 1), "From another app", 600);
        ok(m.view == Model.V_EDIT && m.edit.title.equals("From another app") && m.edit.minutes == 600 && m.edit.rd == rd(2027, 3, 1), "INSERT intent pre-fills the editor");
        m.showDate(rd(2026, 12, 5)); ok(m.view == Model.V_CAL && m.id.equals("Kislev") && m.sel == 25, "VIEW intent jumps to a date");

        // 9) fuzz: random keys / taps must never throw; both languages
        Random rnd = new Random(7);
        for (int round = 0; round < 4; round++) {
            Model f = fresh(); f.he = round % 2 == 1;
            for (int i = 0; i < 100000; i++) {
                f.key(1 + rnd.nextInt(14));
                if (rnd.nextInt(40) == 0) f.act(1 + rnd.nextInt(21), 1 + rnd.nextInt(6), rnd.nextBoolean() ? 1 : -1);
                f.softL(); f.softC(); f.softR();
            }
        }
        ok(true, "400k random keys/taps without exceptions");
        Model e1 = fresh(); for (int i = 0; i < 6000; i++) e1.key(Model.UP); ok(e1.y == Model.MAXY, "year clamps at 9999");
        for (int i = 0; i < 7000; i++) e1.key(Model.DOWN); ok(e1.y == Model.MINY, "year clamps at 3762");
        System.exit(bad == 0 ? 0 : 1);
    }
}
