package com.example.hebrewcalendar;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Check {
    static int bad = 0;
    static void ok(boolean c, String m) { if (!c) { bad++; System.out.println("FAIL " + m); } else System.out.println("ok   " + m); }
    public static void main(String[] a) throws Exception {
        // 1) engine vs JS engine (which was verified against Intl)
        int n = 0, mism = 0;
        for (String line : Files.readAllLines(Paths.get(a[0]))) {
            String[] p = line.split(" ", -1);
            int rd = Integer.parseInt(p[0]);
            HebCal.HDate h = HebCal.rdToHeb(rd);
            HebCal.GDate g = HebCal.rdToGreg(rd);
            StringBuilder hk = new StringBuilder();
            for (HebCal.Hol x : HebCal.holidays(h.y, h.id, h.d, HebCal.dow(rd), false)) hk.append(x.k).append(x.n > 0 ? ":" + x.n : "").append(',');
            String mine = rd + " " + h.y + " " + h.id + " " + h.d + " " + HebCal.dow(rd) + " " + g.y + "-" + g.m + "-" + g.d + " " + hk;
            n++;
            if (!mine.equals(line) || HebCal.hebToRD(h.y, h.id, h.d) != rd) { if (mism++ < 5) System.out.println("DIFF\n " + mine + "\n " + line); }
        }
        ok(mism == 0, n + " days identical to JS engine (" + mism + " mismatches)");
        ok(HebCal.gematria(24).equals("כ״ד") && HebCal.gematria(787).equals("תשפ״ז"), "gematria");

        // 2) key logic, same scenarios as the browser test. Today = 3 Nov 2026 = 23 Cheshvan 5787
        Model m = new Model(HebCal.gregToRD(2026, 11, 3));
        ok(m.y == 5787 && m.id.equals("Cheshvan") && m.sel == 23, "starts at 23 Cheshvan 5787");
        m.key(Model.RIGHT); ok(m.id.equals("Kislev"), "Right -> Kislev");
        m.key(Model.LEFT); m.key(Model.LEFT); ok(m.id.equals("Tishri"), "Left x2 -> Tishri");
        m.key(Model.LEFT); ok(m.id.equals("Elul") && m.y == 5786, "Left -> Elul 5786");
        m.key(Model.RIGHT); ok(m.y == 5787, "Right -> Tishri 5787");
        m.key(Model.UP); ok(m.y == 5788, "Up -> next year");
        m.key(Model.DOWN); m.key(Model.DOWN); ok(m.y == 5786, "Down x2 -> 5786");
        m.key(Model.UP);
        for (int i = 0; i < 5; i++) m.key(Model.RIGHT);
        ok(m.id.equals("AdarI"), "5787 is leap: Adar I");
        m.key(Model.RIGHT); m.key(Model.UP); ok(m.id.equals("Adar") && m.y == 5788, "Adar II -> Adar in 5788");
        m.key(Model.DOWN); ok(m.id.equals("AdarII"), "back to Adar II in 5787");
        m = new Model(HebCal.gregToRD(2026, 11, 3));
        m.key(Model.OK); ok(m.mode == Model.M_DAY, "OK enters day mode");
        m.key(Model.RIGHT); ok(m.sel == 24, "Right -> 24");
        m.key(Model.UP); ok(m.sel == 17, "Up -> 17");
        ok(m.key(Model.BACK) && m.mode == Model.M_BROWSE, "Back leaves day mode");
        ok(!m.key(Model.BACK), "Back in browse mode = exit app (returns false)");
        m.key(Model.OK); m.key(Model.DOWN); m.key(Model.DOWN); m.key(Model.DOWN);
        ok(m.mode == Model.M_BAR, "Down past last row -> bottom bar");
        m.key(Model.RIGHT); m.key(Model.OK); ok(m.view == Model.V_CONV, "bar: OK on Convert opens converter");
        String before = m.hebStr(HebCal.rdToHeb(m.convRD()).y, HebCal.rdToHeb(m.convRD()).id, HebCal.rdToHeb(m.convRD()).d, false);
        m.key(Model.UP);
        HebCal.HDate h = HebCal.rdToHeb(m.convRD());
        ok(h.d == 25 && h.id.equals("Cheshvan"), "converter Up: day +1 -> 25 Cheshvan (" + before + " -> " + m.hebStr(h.y, h.id, h.d, false) + ")");
        m.key(Model.LEFT); ok(m.cf == 0, "Left -> mode toggle focus");
        m.key(Model.OK); ok(!m.g2h, "OK toggles to Hebrew -> Gregorian");
        m.key(Model.RIGHT); m.key(Model.UP); ok(m.sd == 26, "h2g day +1");
        m.cf = 4; m.key(Model.OK); ok(m.view == Model.V_CAL && m.mode == Model.M_DAY && m.sel == 26, "Show in calendar");
        m.key(Model.KS); m.key(Model.OK); ok(m.he, "settings: OK switches to Hebrew");
        m.key(Model.BACK);
        int mi = HebCal.monthIdx(HebCal.monthsOf(m.y), m.id); m.mode = Model.M_BROWSE;
        m.key(Model.LEFT); ok(HebCal.monthIdx(HebCal.monthsOf(m.y), m.id) == mi + 1, "RTL: Left key moves to NEXT month (visual)");
        // 3) fuzz: 200k random keys must never throw
        Random r = new Random(7); Model f = new Model(HebCal.gregToRD(2026, 11, 3));
        for (int i = 0; i < 200000; i++) { f.key(1 + r.nextInt(11)); if (r.nextInt(50) == 0) f.act(1 + r.nextInt(14), 1 + r.nextInt(5), r.nextBoolean() ? 1 : -1); }
        ok(true, "200k random keys/taps without exceptions");
        // extremes
        Model e = new Model(HebCal.gregToRD(2026, 11, 3)); for (int i = 0; i < 6000; i++) e.key(Model.UP); ok(e.y == Model.MAXY, "year clamps at 9999");
        for (int i = 0; i < 7000; i++) e.key(Model.DOWN); ok(e.y == Model.MINY, "year clamps at 3762");
        System.exit(bad == 0 ? 0 : 1);
    }
}
