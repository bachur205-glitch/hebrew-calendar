# Hebrew Calendar (native Android)

Native Android app (Java, no WebView, no libraries, ~100 KB APK). Blue, green and white.
Works with touch, a keyboard, a game pad, a TV remote and a **D-pad**.

| Where | Key | Action |
|---|---|---|
| Calendar | ← → | previous / next **month** |
| Calendar | ↑ ↓ | next / previous **year** (flip in Settings) |
| Calendar | OK | pick a day (cursor appears) |
| Day cursor | arrows | move by day / week (crosses months) |
| Day cursor | OK | open the date converter on that day |
| Day cursor | ↓ on the last row | bottom bar: Today / Convert / Settings |
| Anywhere | Back | step back; Back on the month view closes the app |
| Converter | ← → / ↑ ↓ / OK | choose field / change value / flip direction or show in calendar |
| Settings | ↑ ↓ then ← → / OK | choose and change (language, Israel/Diaspora, flip Up/Down) |

Keyboard extras: `T` today, `C` converter, `S` settings, PageUp / PageDown = ±10 years.

## Get the APK from GitHub (no computer needed)

1. Push this project to a GitHub repo (or upload `android-project.zip` plus `.github/workflows/build.yml`).
2. Open the **Actions** tab and make sure the **Build APK** workflow is enabled. It runs on every push, or tap **Run workflow**.
3. After ~3 minutes open the repo's **Releases** page, download `HebrewCalendar.apk`, and open it to install.
   (Android will ask to allow installs from your browser/file manager once.)

## Test the logic without Android

`javac -d out app/src/main/java/com/example/hebrewcalendar/{HebCal,Model}.java test/Check.java` then run
`java -cp out com.example.hebrewcalendar.Check <dump.txt>`.
