# Hebrew Calendar (native Android)

Native Android app (Java, no WebView, no libraries, small APK). Blue, green and white.
Made for D-pad + soft-key phones, and also works with touch, keyboard, game pad and TV remote.

## Keys

| Where | Key | Action |
|---|---|---|
| Calendar | ← → | previous / next **month** |
| Calendar | ↑ ↓ | next / previous **year** (flip in Settings) |
| Calendar | OK | day cursor (arrows move by day / week), OK again opens the day |
| Calendar | **left soft key** | add an event on the selected day |
| Calendar | **right soft key** (or Menu key, or `M`) | menu: Today, Add event, Upcoming events, Convert dates, Settings |
| Day screen | ← → | previous / next day |
| Day screen | ↑ ↓, OK | choose an event / "+ Add event", open it |
| Day screen | right soft key | Delete (press twice to confirm) |
| Event editor | ↑ ↓ | choose row: Title, Time, Reminder, Repeat, Save, Delete |
| Event editor | ← → | change Time (15-min steps, all-day at the ends), Reminder, Repeat |
| Event editor | OK | Title: type; Time: time picker; Save |
| Event editor | left soft key / right soft key | Save / Cancel |
| Anywhere | Back | step back; Back on the month view closes the app |

## Events and reminders

- Events live on a day: title, time (or all day), reminder (at time, 5 / 10 / 15 / 30 min, 1 / 2 hours, 1 day before) and
  **repeat every year on the same Hebrew date** (birthdays, yahrzeits).
- Days with events show a small bar under the date; holidays show a dot (green = Yom Tov, dark green = Chabad day, blue = other).
- Holidays: all traditional Jewish days (Yom Tov, Chol HaMoed, fasts, Erev days, Purim, Chanukah, Pesach Sheni, Lag BaOmer, Omer count, Rosh Chodesh). No Israeli state days.
- Chabad-Chassidic days (Yud Tes Kislev, Yud Shevat, Gimmel Tammuz, Chai Elul, etc.) can be turned off in Settings > Chabad days.
- The navigation bar is hidden so the soft-key bar sits at the very bottom of the screen.
- Reminders are real notifications (they work when the app is closed and after a reboot).
  Android 13+ asks for notification permission the first time you save an event with a reminder.
  All-day reminders fire at 09:00.
- Events are stored inside the app. They are not shared with Google Calendar.

## Recognized as a calendar app

The app declares the standard calendar intents: `APP_CALENDAR` (the "open calendar" category), viewing a day
(`content://com.android.calendar/time/...`), and adding an event (`INSERT`/`EDIT` of `vnd.android.cursor.dir/event`).
Other apps and launchers can therefore pick it when they ask Android for a calendar.

## Get the APK from GitHub

Push to the repo (or upload `android-project.zip` plus the workflow). The **Build APK** workflow runs on every push
and publishes `HebrewCalendar.apk` on the repo's **Releases** page.

## Test the logic without Android

`javac -d out app/src/main/java/com/example/hebrewcalendar/{HebCal,EventStore,Model}.java test/Check.java`
then `java -cp out com.example.hebrewcalendar.Check <dump.txt>`.
