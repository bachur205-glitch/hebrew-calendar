package com.example.hebrewcalendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarms are lost on reboot, app update and clock/time-zone changes, so set them up again. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Reminders.rescheduleAll(context, Reminders.load(context));
    }
}
