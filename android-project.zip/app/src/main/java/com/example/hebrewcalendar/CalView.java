package com.example.hebrewcalendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** One custom view that draws every screen and handles D-pad, soft keys, keyboard and touch. */
public class CalView extends View {
    private static final int BLUE = 0xFF1565C0, BLUE_D = 0xFF0D47A1, BLUE_L = 0xFFE3F0FC;
    private static final int GREEN = 0xFF2E9E5B, GREEN_D = 0xFF1F7A43, GREEN_L = 0xFFE4F5EA;
    private static final int INK = 0xFF12304F, MUTE = 0xFF6B84A0, GRID = 0xFFE3ECF6, WHITE = 0xFFFFFFFF;
    private static final int GLOW = 0x401565C0, CHIP_RC = 0xFF9CC3EC, SCRIM = 0x66102A43;

    private static final class Hit {
        final RectF r; final int a, arg, arg2;
        Hit(RectF r, int a, int arg, int arg2) { this.r = r; this.a = a; this.arg = arg; this.arg2 = arg2; }
    }

    private final Model m;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();
    private final List<Hit> hits = new ArrayList<Hit>();
    private Canvas cv;
    private float u;  // layout unit: 1% of the shorter screen side (may be shrunk per screen)
    private float u0; // the unshrunk unit, used for the soft-key bar

    public CalView(Context ctx, Model model) {
        super(ctx);
        m = model;
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    // ------------------------------------------------------------------ drawing helpers
    private void fill(float l, float t, float rt, float b, float rad, int color) {
        r.set(l, t, rt, b);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        if (rad > 0) cv.drawRoundRect(r, rad, rad, p); else cv.drawRect(r, p);
    }
    private void stroke(float l, float t, float rt, float b, float rad, int color, float width) {
        r.set(l, t, rt, b);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(width);
        p.setColor(color);
        if (rad > 0) cv.drawRoundRect(r, rad, rad, p); else cv.drawRect(r, p);
        p.setStyle(Paint.Style.FILL);
    }
    private void circle(float x, float y, float rad, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        cv.drawCircle(x, y, rad, p);
    }
    /** Draws text vertically centred on cy. Shrinks to fit maxW (use 0 for no limit). */
    private void text(String s, float x, float cy, float size, int color, boolean bold, Paint.Align al, float maxW) {
        p.setStyle(Paint.Style.FILL);
        p.setFakeBoldText(bold);
        p.setTextAlign(al);
        p.setColor(color);
        size = Math.max(size, 9f);
        p.setTextSize(size);
        if (maxW > 0) {
            float wdt = p.measureText(s);
            if (wdt > maxW) p.setTextSize(Math.max(7f, size * maxW / wdt));
        }
        cv.drawText(s, x, cy - (p.ascent() + p.descent()) / 2f, p);
        p.setFakeBoldText(false);
    }
    private void center(String s, float x, float cy, float size, int color, boolean bold, float maxW) {
        text(s, x, cy, size, color, bold, Paint.Align.CENTER, maxW);
    }
    private float textWidth(String s, float size, boolean bold) {
        p.setFakeBoldText(bold);
        p.setTextSize(Math.max(size, 9f));
        float w = p.measureText(s);
        p.setFakeBoldText(false);
        return w;
    }
    private void triangle(float cx, float cy, float s, boolean up, int color) {
        path.reset();
        if (up) { path.moveTo(cx, cy - s); path.lineTo(cx + s * 1.1f, cy + s * 0.7f); path.lineTo(cx - s * 1.1f, cy + s * 0.7f); }
        else { path.moveTo(cx, cy + s); path.lineTo(cx + s * 1.1f, cy - s * 0.7f); path.lineTo(cx - s * 1.1f, cy - s * 0.7f); }
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        cv.drawPath(path, p);
    }
    private void hit(float l, float t, float rt, float b, int a, int arg, int arg2) {
        hits.add(new Hit(new RectF(l, t, rt, b), a, arg, arg2));
    }
    private void focusRing(float l, float t, float rt, float b, float rad) {
        stroke(l - 0.5f * u, t - 0.5f * u, rt + 0.5f * u, b + 0.5f * u, rad, GLOW, 1.8f * u);
        stroke(l, t, rt, b, rad, BLUE, 0.7f * u);
    }
    private void button(float l, float t, float rt, float b, String label, int bg, int fg, boolean focus, int a, int arg) {
        fill(l, t, rt, b, 1.4f * u, bg);
        center(label, (l + rt) / 2, (t + b) / 2, 3.7f * u, fg, true, rt - l - 1.5f * u);
        if (focus) focusRing(l, t, rt, b, 1.4f * u);
        hit(l, t, rt, b, a, arg, 0);
    }

    // ------------------------------------------------------------------------- draw
    @Override
    protected void onDraw(Canvas c) {
        cv = c;
        hits.clear();
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        u = u0 = Math.min(w, h) / 100f;
        c.drawColor(WHITE);
        switch (m.view) {
            case Model.V_CAL: drawCalendar(w, h); break;
            case Model.V_DAY: drawDay(w, h); break;
            case Model.V_EDIT: drawEdit(w, h); break;
            case Model.V_UP: drawUpcoming(w, h); break;
            case Model.V_CONV: drawConverter(w, h); break;
            default: drawSettings(w, h); break;
        }
        u = u0;
        drawSoftBar(w, h);
        if (m.view == Model.V_CAL && m.menuOpen) drawMenu(w, h);
    }

    /** The three soft-key labels along the bottom. Tapping them does the same as pressing the keys. */
    private void drawSoftBar(int w, int h) {
        float bh = 9 * u0, y = h - bh;
        fill(0, y, w, h, 0, BLUE_L);
        fill(0, y, w, y + 0.25f * u0, 0, GRID);
        float third = w / 3f;
        text(m.softL(), 2.5f * u0, y + bh / 2, 3.8f * u0, BLUE_D, true, Paint.Align.LEFT, third - 3 * u0);
        center(m.softC(), w / 2f, y + bh / 2, 3.8f * u0, GREEN_D, true, third - 2 * u0);
        text(m.softR(), w - 2.5f * u0, y + bh / 2, 3.8f * u0, BLUE_D, true, Paint.Align.RIGHT, third - 3 * u0);
        hit(0, y, third, h, Model.A_SOFTL, 0, 0);
        hit(third, y, 2 * third, h, Model.A_OK, 0, 0);
        hit(2 * third, y, w, h, Model.A_SOFTR, 0, 0);
    }

    private void drawHeader(int w, float hh, String title, String sub, String line3) {
        fill(0, 0, w, hh, 0, BLUE);
        center(title, w / 2f, hh * 0.30f, 6.6f * u, WHITE, true, w - 28 * u);
        if (sub != null) center(sub, w / 2f, hh * 0.52f, 3.7f * u, WHITE, false, w - 28 * u);
        if (line3 != null) center(line3, w / 2f, hh * 0.69f, 3f * u, 0xDDFFFFFF, false, w - 4 * u);
    }

    private void navCircles(float cy, int actLeft, int actRight) {
        float nr = 5.2f * u, lx = 8 * u, rx = getWidth() - 8 * u;
        circle(lx, cy, nr, 0x30FFFFFF); center("‹", lx, cy - 0.3f * u, 8 * u, WHITE, true, 0);
        circle(rx, cy, nr, 0x30FFFFFF); center("›", rx, cy - 0.3f * u, 8 * u, WHITE, true, 0);
        hit(lx - nr, cy - nr, lx + nr, cy + nr, actLeft, 0, 0);
        hit(rx - nr, cy - nr, rx + nr, cy + nr, actRight, 0, 0);
    }

    // ------------------------------------------------------------------- calendar
    private void drawCalendar(int w, int h) {
        float hh = 25 * u;
        int selRD = m.selRD(), wd = HebCal.dow(selRD);
        String line3 = gregSpan();
        if (m.mode == Model.M_DAY) {
            line3 = m.gregStr(HebCal.rdToGreg(selRD), wd);
            String hol = m.holidayLine(m.y, m.id, m.sel, wd);
            if (hol.length() > 0) line3 += "  ·  " + hol;
        }
        drawHeader(w, hh, Model.monthName(m.id, m.he),
                Model.monthName(m.id, !m.he) + " " + (m.he ? String.valueOf(m.y) : HebCal.gematria(m.y % 1000)), line3);
        // month arrows sit where the keys point (in Hebrew, "next" is on the left)
        navCircles(hh * 0.40f, m.he ? Model.A_NEXT : Model.A_PREV, m.he ? Model.A_PREV : Model.A_NEXT);
        // year row
        float yy = hh * 0.86f, bw = 6.5f * u, bh = 4.6f * u;
        center(String.valueOf(m.y), w / 2f, yy, 4.2f * u, WHITE, true, 0);
        float lb = w / 2f - 13 * u, rb = w / 2f + 13 * u;
        fill(lb - bw / 2, yy - bh / 2, lb + bw / 2, yy + bh / 2, 1.2f * u, 0x30FFFFFF);
        fill(rb - bw / 2, yy - bh / 2, rb + bw / 2, yy + bh / 2, 1.2f * u, 0x30FFFFFF);
        triangle(lb, yy, 1.5f * u, false, WHITE);
        triangle(rb, yy, 1.5f * u, true, WHITE);
        hit(lb - bw / 2, yy - bh / 2, lb + bw / 2, yy + bh / 2, m.upDir() > 0 ? Model.A_YDOWN : Model.A_YUP, 0, 0);
        hit(rb - bw / 2, yy - bh / 2, rb + bw / 2, yy + bh / 2, m.upDir() > 0 ? Model.A_YUP : Model.A_YDOWN, 0, 0);

        // the grid takes ALL the space between the header and the soft-key bar
        float gx = 1 * u, gy = hh + 1 * u, gw = w - 2 * u, gh = h - gy - 9 * u0 - 1 * u;
        drawGrid(gx, gy, gw, gh);
    }

    private String gregSpan() {
        HebCal.Month[] ms = HebCal.monthsOf(m.y);
        int len = ms[HebCal.monthIdx(ms, m.id)].len, first = HebCal.hebToRD(m.y, m.id, 1);
        HebCal.GDate a = HebCal.rdToGreg(first), b = HebCal.rdToGreg(first + len - 1);
        if (a.y == b.y) return (a.m == b.m ? m.gm(a.m) : m.gm(a.m) + " – " + m.gm(b.m)) + " " + a.y;
        return m.gms(a.m) + " " + a.y + " – " + m.gms(b.m) + " " + b.y;
    }

    private void drawGrid(float gx, float gy, float gw, float gh) {
        float wdh = 5 * u, cw = gw / 7f, rh = (gh - wdh) / 6f;
        fill(gx, gy, gx + gw, gy + wdh, 1f * u, BLUE_L);
        for (int i = 0; i < 7; i++) {
            int col = m.he ? 6 - i : i;
            center(m.wdShort(i), gx + (col + 0.5f) * cw, gy + wdh / 2, 2.9f * u, i == 6 ? GREEN_D : BLUE, true, cw);
        }
        HebCal.Month[] ms = HebCal.monthsOf(m.y);
        int len = ms[HebCal.monthIdx(ms, m.id)].len;
        int first = HebCal.hebToRD(m.y, m.id, 1), sd = HebCal.dow(first);
        float unit = Math.min(cw, rh);
        float curL = 0, curT = 0; boolean haveCur = false;
        for (int i = 0; i < 42; i++) {
            int d = i - sd + 1;
            if (d < 1 || d > len) continue;
            int col = m.he ? 6 - (i % 7) : i % 7, row = i / 7;
            float l = gx + col * cw, t = gy + wdh + row * rh;
            int rd = first + d - 1;
            boolean today = rd == m.todayRD, sat = i % 7 == 6;
            fill(l, t, l + cw, t + rh, 0, today ? GREEN : sat ? GREEN_L : WHITE);
            stroke(l, t, l + cw, t + rh, 0, GRID, 0.2f * u);
            center(m.dayLabel(d), l + cw / 2, t + rh * 0.40f, unit * 0.36f, today ? WHITE : INK, true, cw - 0.6f * u);
            HebCal.GDate g = HebCal.rdToGreg(rd);
            String gs = g.d == 1 ? g.d + " " + m.gms(g.m) : String.valueOf(g.d);
            center(gs, l + cw / 2, t + rh * 0.68f, unit * 0.2f, today ? 0xE6FFFFFF : MUTE, false, cw);
            // markers: dot = holiday (green = yom tov), bar = you have an event that day
            List<HebCal.Hol> hs = m.holidays(m.y, m.id, d, i % 7);
            boolean hasHol = false, hasEv = m.store.any(rd), major = false, chab = false;
            for (HebCal.Hol x : hs) {
                if (x.t.equals("omer")) continue;
                hasHol = true;
                if (x.t.equals("major")) major = true;
                if (x.t.equals("chabad")) chab = true;
            }
            if (major) chab = false;
            float my = t + rh * 0.89f, dr = Math.max(0.5f * u, unit * 0.045f);
            float pillW = dr * 4.2f, total = (hasHol ? dr * 2 : 0) + (hasHol && hasEv ? dr * 1.5f : 0) + (hasEv ? pillW : 0);
            float mx = l + cw / 2 - total / 2;
            if (hasHol) { circle(mx + dr, my, dr, today ? WHITE : major ? GREEN : chab ? GREEN_D : BLUE); mx += dr * 3.5f; }
            if (hasEv) fill(mx, my - dr, mx + pillW, my + dr, dr, today ? WHITE : BLUE_D);
            if (d == m.sel) {
                if (m.mode == Model.M_DAY) { curL = l; curT = t; haveCur = true; }
                else stroke(l + 0.3f * u, t + 0.3f * u, l + cw - 0.3f * u, t + rh - 0.3f * u, 0, BLUE, 0.5f * u);
            }
            hit(l, t, l + cw, t + rh, Model.A_CELL, d, 0);
        }
        if (haveCur) {
            stroke(curL - 0.2f * u, curT - 0.2f * u, curL + cw + 0.2f * u, curT + rh + 0.2f * u, 0.6f * u, GLOW, 2.2f * u);
            stroke(curL, curT, curL + cw, curT + rh, 0.4f * u, BLUE, 0.9f * u);
        }
    }

    // ------------------------------------------------------------------------ menu
    private void drawMenu(int w, int h) {
        float soft = 9 * u0;
        fill(0, 0, w, h - soft, 0, SCRIM);
        hit(0, 0, w, h - soft, Model.A_MENUCLOSE, 0, 0);
        String[] items = m.menuLabels();
        float rowH = 10 * u, pw = Math.min(w - 4 * u, 72 * u), ph = items.length * rowH + 2 * u;
        float x = w - 2 * u - pw, y = h - soft - 1.5f * u - ph;
        fill(x, y, x + pw, y + ph, 2 * u, WHITE);
        stroke(x, y, x + pw, y + ph, 2 * u, BLUE, 0.4f * u);
        hit(x, y, x + pw, y + ph, Model.A_MENUCLOSE + 100, 0, 0); // swallow taps on the panel gaps (unknown action = no-op)
        for (int i = 0; i < items.length; i++) {
            float ty = y + u + i * rowH;
            boolean foc = i == m.menuIdx;
            if (foc) fill(x + 0.8f * u, ty, x + pw - 0.8f * u, ty + rowH, 1.4f * u, BLUE);
            text(items[i], m.he ? x + pw - 3 * u : x + 3 * u, ty + rowH / 2, 4.2f * u, foc ? WHITE : INK, foc,
                    m.he ? Paint.Align.RIGHT : Paint.Align.LEFT, pw - 6 * u);
            hit(x, ty, x + pw, ty + rowH, Model.A_MENUITEM, i, 0);
        }
    }

    // ---------------------------------------------------------------------- day screen
    private void drawDay(int w, int h) {
        float hh = 22 * u;
        int rd = m.selRD(), wd = HebCal.dow(rd);
        String hol = m.holidayLine(m.y, m.id, m.sel, wd);
        drawHeader(w, hh, m.hebStr(m.y, m.id, m.sel, m.he), m.gregStr(HebCal.rdToGreg(rd), wd),
                hol.length() > 0 ? hol : m.hebStr(m.y, m.id, m.sel, !m.he));
        navCircles(hh * 0.40f, m.he ? Model.A_NEXT : Model.A_PREV, m.he ? Model.A_PREV : Model.A_NEXT);

        List<EventStore.Event> ev = m.dayEvents();
        int n = ev.size();
        m.dayIdx = Model.clamp(m.dayIdx, 0, n);
        float rowH = 13.5f * u, gap = 1.6f * u, top = hh + 2 * u, bottom = h - 9 * u0 - 1 * u;
        if (n == 0) { center(m.s(Model.S_NOEVENTS), w / 2f, top + 3 * u, 3.6f * u, MUTE, false, w - 6 * u); top += 7 * u; }
        int visible = Math.max(1, (int) ((bottom - top + gap) / (rowH + gap)));
        if (m.dayIdx < m.dayScroll) m.dayScroll = m.dayIdx;
        if (m.dayIdx >= m.dayScroll + visible) m.dayScroll = m.dayIdx - visible + 1;
        float x = 2 * u, rw = w - 4 * u;
        for (int i = m.dayScroll; i <= n && i < m.dayScroll + visible; i++) {
            float y = top + (i - m.dayScroll) * (rowH + gap);
            boolean foc = i == m.dayIdx;
            fill(x, y, x + rw, y + rowH, 1.6f * u, i < n ? BLUE_L : GREEN_L);
            if (i < n) {
                EventStore.Event e = ev.get(i);
                float tw = 18 * u;
                boolean rtl = m.he;
                float tx = rtl ? x + rw - 2.5f * u : x + 2.5f * u;
                Paint.Align al = rtl ? Paint.Align.RIGHT : Paint.Align.LEFT;
                float cx = rtl ? x + rw - tw - 2.5f * u : x + tw + 2.5f * u;
                text(m.timeLabel(e.minutes), tx, y + rowH / 2, 3.8f * u, GREEN_D, true, al, tw - 1 * u);
                text(e.title, cx, y + rowH * 0.36f, 4.3f * u, INK, true, al, rw - tw - 6 * u);
                String sub = (e.remind >= 0 ? m.remindLabel(e.remind) : "") + (e.yearly ? (e.remind >= 0 ? "  ·  " : "") + m.s(Model.S_YEARLY) : "");
                if (sub.length() > 0) text(sub, cx, y + rowH * 0.74f, 2.8f * u, MUTE, false, al, rw - tw - 6 * u);
            } else {
                center("+  " + m.s(Model.S_ADDEV), x + rw / 2, y + rowH / 2, 4.2f * u, GREEN_D, true, rw - 4 * u);
            }
            if (foc) focusRing(x, y, x + rw, y + rowH, 1.6f * u);
            hit(x, y, x + rw, y + rowH, Model.A_ROW, i, 0);
        }
    }

    // ----------------------------------------------------------------- event editor
    private void drawSubHeader(int w, float hh, String title, String sub) {
        fill(0, 0, w, hh, 0, BLUE);
        center(title, w / 2f, sub == null ? hh / 2f : hh * 0.38f, 5.6f * u, WHITE, true, w - 28 * u);
        if (sub != null) center(sub, w / 2f, hh * 0.74f, 3.2f * u, 0xDDFFFFFF, false, w - 8 * u);
        float bx = m.he ? w - 8 * u : 8 * u;
        circle(bx, hh / 2f, 4.6f * u, 0x30FFFFFF);
        center(m.he ? "›" : "‹", bx, hh / 2f - 0.3f * u, 7 * u, WHITE, true, 0);
        hit(bx - 5 * u, 0, bx + 5 * u, hh, Model.A_BACK, 0, 0);
    }

    private void drawEdit(int w, int h) {
        u = Math.min(u, (h - 9 * u0) / 106f);
        float hh = 15 * u;
        int rd = m.edit.rd;
        drawSubHeader(w, hh, m.s(m.editNew ? Model.S_NEWEVENT : Model.S_EDITEVENT),
                m.gregStr(HebCal.rdToGreg(rd), HebCal.dow(rd)));
        float cw = Math.min(w - 6 * u, 120 * u), left = (w - cw) / 2f, y = hh + 2.5f * u, rh = 11.5f * u, gap = 1.8f * u;
        EventStore.Event e = m.edit;
        String[] labs = {m.s(Model.S_TITLE), m.s(Model.S_TIME), m.s(Model.S_REMIND), m.s(Model.S_REPEAT)};
        String[] vals = {e.title.length() == 0 ? m.s(Model.S_TAP) : e.title, m.timeLabel(e.minutes), m.remindLabel(e.remind),
                e.yearly ? m.s(Model.S_YEARLY) : m.s(Model.S_ONCE)};
        for (int i = 0; i < m.editRows(); i++) {
            boolean foc = m.editField == i;
            if (i < 4) {
                fill(left, y, left + cw, y + rh, 1.6f * u, foc ? BLUE_L : WHITE);
                stroke(left, y, left + cw, y + rh, 1.6f * u, foc ? BLUE : GRID, foc ? 0.5f * u : 0.35f * u);
                if (foc) focusRing(left, y, left + cw, y + rh, 1.6f * u);
                Paint.Align a1 = m.he ? Paint.Align.RIGHT : Paint.Align.LEFT, a2 = m.he ? Paint.Align.LEFT : Paint.Align.RIGHT;
                text(labs[i], m.he ? left + cw - 3 * u : left + 3 * u, y + rh / 2, 3.6f * u, MUTE, false, a1, cw * 0.28f);
                boolean placeholder = i == 0 && e.title.length() == 0;
                text(vals[i], m.he ? left + 3 * u : left + cw - 3 * u, y + rh / 2, 4.1f * u, placeholder ? MUTE : GREEN_D, !placeholder, a2, cw * 0.66f);
                hit(left, y, left + cw, y + rh, Model.A_ROW, i, 0);
            } else if (i == Model.F_SAVE) {
                button(left, y, left + cw, y + rh, m.s(Model.S_SAVE), GREEN, WHITE, foc, Model.A_ROW, i);
            } else {
                button(left, y, left + cw, y + rh, m.s(Model.S_DELETE), BLUE_L, BLUE_D, foc, Model.A_ROW, i);
            }
            y += rh + gap;
        }
    }

    // --------------------------------------------------------------- upcoming events
    private void drawUpcoming(int w, int h) {
        float hh = 14 * u;
        drawSubHeader(w, hh, m.s(Model.S_UPCOMING), null);
        int n = m.up.size();
        if (n == 0) { center(m.s(Model.S_NOUP), w / 2f, (h - 9 * u0) / 2f, 4.4f * u, MUTE, false, w - 8 * u); return; }
        float rowH = 13.5f * u, gap = 1.6f * u, top = hh + 2 * u, bottom = h - 9 * u0 - 1 * u;
        int visible = Math.max(1, (int) ((bottom - top + gap) / (rowH + gap)));
        if (m.upIdx < m.upScroll) m.upScroll = m.upIdx;
        if (m.upIdx >= m.upScroll + visible) m.upScroll = m.upIdx - visible + 1;
        float x = 2 * u, rw = w - 4 * u;
        Paint.Align al = m.he ? Paint.Align.RIGHT : Paint.Align.LEFT;
        float tx = m.he ? x + rw - 3 * u : x + 3 * u;
        for (int i = m.upScroll; i < n && i < m.upScroll + visible; i++) {
            Model.Up it = m.up.get(i);
            float y = top + (i - m.upScroll) * (rowH + gap);
            fill(x, y, x + rw, y + rowH, 1.6f * u, BLUE_L);
            HebCal.HDate hd = HebCal.rdToHeb(it.rd);
            String when = m.gregShort(HebCal.rdToGreg(it.rd), HebCal.dow(it.rd)) + "  ·  " + m.hebStr(hd.y, hd.id, hd.d, m.he)
                    + (it.e.minutes >= 0 ? "  ·  " + m.timeLabel(it.e.minutes) : "");
            text(when, tx, y + rowH * 0.30f, 2.9f * u, GREEN_D, true, al, rw - 6 * u);
            text(it.e.title, tx, y + rowH * 0.68f, 4.3f * u, INK, true, al, rw - 6 * u);
            if (i == m.upIdx) focusRing(x, y, x + rw, y + rowH, 1.6f * u);
            hit(x, y, x + rw, y + rowH, Model.A_ROW, i, 0);
        }
    }

    // ------------------------------------------------------------------ converter
    private void drawConverter(int w, int h) {
        u = Math.min(u, (h - 9 * u0) / 108f);
        float hh = 14 * u;
        drawSubHeader(w, hh, m.s(Model.S_CONVTITLE), null);
        float cw = Math.min(w - 6 * u, 115 * u), left = (w - cw) / 2f, y = hh + 3 * u;
        float mh = 10 * u;
        fill(left, y, left + cw, y + mh, 1.6f * u, BLUE_L);
        center((m.g2h ? m.s(Model.S_G2H) : m.s(Model.S_H2G)) + "  ↔", left + cw / 2, y + mh / 2, 4f * u, BLUE_D, true, cw - 3 * u);
        if (m.cf == 0) focusRing(left, y, left + cw, y + mh, 1.6f * u);
        hit(left, y, left + cw, y + mh, Model.A_TOGGLE, 0, 0);
        y += mh + 2.5f * u;
        String[] vals, labs = {m.s(Model.S_DAY), m.s(Model.S_MONTH), m.s(Model.S_YEAR)};
        if (m.g2h) vals = new String[]{String.valueOf(m.sd), m.gm(m.sm), String.valueOf(m.sy)};
        else vals = new String[]{m.dayLabel(m.sd), Model.monthName(m.sid, m.he), String.valueOf(m.sy)};
        float gap = 2 * u, unitW = (cw - 2 * gap) / 3.9f;
        float[] ws = {unitW, unitW * 1.6f, unitW * 1.3f};
        float sh = 32 * u;
        for (int j = 0; j < 3; j++) {
            int pos = m.he ? 2 - j : j;
            float xl = left;
            for (int q = 0; q < pos; q++) xl += ws[m.he ? 2 - q : q] + gap;
            float xr = xl + ws[j];
            boolean foc = m.cf == j + 1;
            fill(xl, y, xr, y + sh, 1.6f * u, foc ? BLUE_L : WHITE);
            stroke(xl, y, xr, y + sh, 1.6f * u, foc ? BLUE : GRID, foc ? 0.5f * u : 0.35f * u);
            if (foc) focusRing(xl, y, xr, y + sh, 1.6f * u);
            center(labs[j], (xl + xr) / 2, y + 3.4f * u, 2.6f * u, MUTE, false, ws[j]);
            triangle((xl + xr) / 2, y + 9.5f * u, 2f * u, true, BLUE);
            center(vals[j], (xl + xr) / 2, y + 16.5f * u, 5.4f * u, INK, true, ws[j] - 1.5f * u);
            triangle((xl + xr) / 2, y + 24 * u, 2f * u, false, BLUE);
            hit(xl, y, xr, y + sh, Model.A_FIELD, j + 1, 0); // added first: later (more specific) hits win
            hit(xl, y + 5.5f * u, xr, y + 13 * u, Model.A_ADJ, j + 1, 1);
            hit(xl, y + 20 * u, xr, y + sh, Model.A_ADJ, j + 1, -1);
        }
        y += sh + 2.5f * u;
        int rd = m.convRD();
        HebCal.HDate hd = HebCal.rdToHeb(rd);
        HebCal.GDate gd = HebCal.rdToGreg(rd);
        int wd = HebCal.dow(rd);
        String r1, r2;
        if (m.g2h) { r1 = m.hebStr(hd.y, hd.id, hd.d, m.he); r2 = m.hebStr(hd.y, hd.id, hd.d, !m.he); }
        else { r1 = m.gregStr(gd, wd); r2 = m.wd(wd); }
        String hs = m.holidayLine(hd.y, hd.id, hd.d, wd);
        float rh = 28 * u;
        fill(left, y, left + cw, y + rh, 2f * u, GREEN);
        center(m.s(Model.S_RESULT), left + cw / 2, y + 3.4f * u, 2.6f * u, 0xD9FFFFFF, false, 0);
        center(r1, left + cw / 2, y + 10.5f * u, 6f * u, WHITE, true, cw - 4 * u);
        center(r2, left + cw / 2, y + 17.5f * u, 3.8f * u, 0xF2FFFFFF, false, cw - 4 * u);
        if (hs.length() > 0) center(hs, left + cw / 2, y + 23.5f * u, 3f * u, 0xE6FFFFFF, false, cw - 4 * u);
        y += rh + 2.5f * u;
        button(left, y, left + cw, y + 10 * u, m.s(Model.S_SHOW), BLUE, WHITE, m.cf == 4, Model.A_SHOW, 0);
    }

    // ------------------------------------------------------------------- settings
    private void drawSettings(int w, int h) {
        u = Math.min(u, (h - 9 * u0) / 80f);
        float hh = 14 * u;
        drawSubHeader(w, hh, m.s(Model.S_SETTITLE), null);
        String[] labels = {m.s(Model.S_LANG), m.s(Model.S_HOL), m.s(Model.S_CHABAD), m.s(Model.S_UD)};
        String[] vals = {m.he ? "עברית" : "English", m.israel ? m.s(Model.S_ISR) : m.s(Model.S_DIA),
                m.chabad ? m.s(Model.S_ON) : m.s(Model.S_OFF), m.invY ? m.s(Model.S_UD1) : m.s(Model.S_UD0)};
        float cw = Math.min(w - 6 * u, 115 * u), left = (w - cw) / 2f, y = hh + 3 * u, rh = 12 * u;
        for (int i = 0; i < 4; i++) {
            boolean foc = m.setIdx == i;
            fill(left, y, left + cw, y + rh, 1.8f * u, foc ? BLUE_L : WHITE);
            stroke(left, y, left + cw, y + rh, 1.8f * u, foc ? BLUE : GRID, foc ? 0.5f * u : 0.35f * u);
            if (foc) focusRing(left, y, left + cw, y + rh, 1.8f * u);
            Paint.Align a1 = m.he ? Paint.Align.RIGHT : Paint.Align.LEFT, a2 = m.he ? Paint.Align.LEFT : Paint.Align.RIGHT;
            text(labels[i], m.he ? left + cw - 3 * u : left + 3 * u, y + rh / 2, 4f * u, INK, false, a1, cw * 0.45f);
            text(vals[i], m.he ? left + 3 * u : left + cw - 3 * u, y + rh / 2, 4f * u, GREEN_D, true, a2, cw * 0.5f);
            hit(left, y, left + cw, y + rh, Model.A_SETROW, i, 0);
            y += rh + 2.5f * u;
        }
    }

    // ----------------------------------------------------------------------- input
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int k;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP: k = Model.UP; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: k = Model.DOWN; break;
            case KeyEvent.KEYCODE_DPAD_LEFT: k = Model.LEFT; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: k = Model.RIGHT; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A: k = Model.OK; break;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_B: k = Model.BACK; break;
            case KeyEvent.KEYCODE_SOFT_LEFT: k = Model.SOFTL; break;
            case KeyEvent.KEYCODE_SOFT_RIGHT: k = Model.SOFTR; break;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_M: k = Model.MENU; break;
            case KeyEvent.KEYCODE_PAGE_UP: k = Model.PGUP; break;
            case KeyEvent.KEYCODE_PAGE_DOWN: k = Model.PGDN; break;
            case KeyEvent.KEYCODE_T: k = Model.KT; break;
            case KeyEvent.KEYCODE_C: k = Model.KC; break;
            case KeyEvent.KEYCODE_S: k = Model.KS; break;
            default: return super.onKeyDown(keyCode, event);
        }
        boolean handled = m.key(k);
        if (handled) invalidate();
        return handled; // an unhandled BACK falls through and closes the app
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getAction();
        if (a == MotionEvent.ACTION_DOWN) return true;
        if (a == MotionEvent.ACTION_UP) {
            float x = e.getX(), y = e.getY();
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit ht = hits.get(i);
                if (ht.r.contains(x, y)) { m.act(ht.a, ht.arg, ht.arg2); invalidate(); break; }
            }
            return true;
        }
        return super.onTouchEvent(e);
    }
}
