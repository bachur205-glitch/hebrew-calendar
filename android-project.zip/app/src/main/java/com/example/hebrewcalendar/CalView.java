package com.example.hebrewcalendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** One custom view that draws the whole app (calendar, converter, settings) and handles D-pad, keyboard and touch. */
public class CalView extends View {
    private static final int BLUE = 0xFF1565C0, BLUE_D = 0xFF0D47A1, BLUE_L = 0xFFE3F0FC;
    private static final int GREEN = 0xFF2E9E5B, GREEN_D = 0xFF1F7A43, GREEN_L = 0xFFE4F5EA;
    private static final int INK = 0xFF12304F, MUTE = 0xFF6B84A0, GRID = 0xFFE3ECF6, WHITE = 0xFFFFFFFF;
    private static final int GLOW = 0x401565C0, CHIP_RC = 0xFF9CC3EC;

    private static final class Hit {
        final RectF r; final int a, arg, arg2;
        Hit(RectF r, int a, int arg, int arg2) { this.r = r; this.a = a; this.arg = arg; this.arg2 = arg2; }
    }

    private final Model m;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();
    private final List<Hit> hits = new ArrayList<Hit>();
    private Canvas cv;
    private float u; // layout unit: 1% of the shorter screen side

    public CalView(Context ctx, Model model) {
        super(ctx);
        m = model;
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    // ------------------------------------------------------------------ drawing helpers
    private void fill(float l, float t, float rt, float b, float rad, int color) {
        r.set(l, t, rt, b);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        if (rad > 0) cv.drawRoundRect(r, rad, rad, p); else cv.drawRect(r, p);
    }
    private void stroke(float l, float t, float rt, float b, float rad, int color, float width) {
        r.set(l, t, rt, b);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(width);
        p.setColor(color);
        if (rad > 0) cv.drawRoundRect(r, rad, rad, p); else cv.drawRect(r, p);
        p.setStyle(Paint.Style.FILL);
    }
    private void circle(float x, float y, float rad, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        cv.drawCircle(x, y, rad, p);
    }
    /** Draws text vertically centred on cy. Shrinks to fit maxW (use 0 for no limit). */
    private void text(String s, float x, float cy, float size, int color, boolean bold, Paint.Align al, float maxW) {
        p.setStyle(Paint.Style.FILL);
        p.setFakeBoldText(bold);
        p.setTextAlign(al);
        p.setColor(color);
        p.setTextSize(size);
        if (maxW > 0) {
            float wdt = p.measureText(s);
            if (wdt > maxW) p.setTextSize(size * maxW / wdt);
        }
        cv.drawText(s, x, cy - (p.ascent() + p.descent()) / 2f, p);
        p.setFakeBoldText(false);
    }
    private void center(String s, float x, float cy, float size, int color, boolean bold, float maxW) {
        text(s, x, cy, size, color, bold, Paint.Align.CENTER, maxW);
    }
    private float textWidth(String s, float size, boolean bold) {
        p.setFakeBoldText(bold);
        p.setTextSize(size);
        float w = p.measureText(s);
        p.setFakeBoldText(false);
        return w;
    }
    private void triangle(float cx, float cy, float s, boolean up, int color) {
        path.reset();
        if (up) { path.moveTo(cx, cy - s); path.lineTo(cx + s * 1.1f, cy + s * 0.7f); path.lineTo(cx - s * 1.1f, cy + s * 0.7f); }
        else { path.moveTo(cx, cy + s); path.lineTo(cx + s * 1.1f, cy - s * 0.7f); path.lineTo(cx - s * 1.1f, cy - s * 0.7f); }
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        cv.drawPath(path, p);
    }
    private void hit(float l, float t, float rt, float b, int a, int arg, int arg2) {
        hits.add(new Hit(new RectF(l, t, rt, b), a, arg, arg2));
    }
    private void focusRing(float l, float t, float rt, float b, float rad) {
        stroke(l - 0.5f * u, t - 0.5f * u, rt + 0.5f * u, b + 0.5f * u, rad, GLOW, 1.8f * u);
        stroke(l, t, rt, b, rad, BLUE, 0.7f * u);
    }
    private void button(float l, float t, float rt, float b, String label, int bg, int fg, boolean focus, int a, int arg) {
        fill(l, t, rt, b, 1.4f * u, bg);
        center(label, (l + rt) / 2, (t + b) / 2, 3.7f * u, fg, true, rt - l - 1.5f * u);
        if (focus) focusRing(l, t, rt, b, 1.4f * u);
        hit(l, t, rt, b, a, arg, 0);
    }

    // ------------------------------------------------------------------------- draw
    @Override
    protected void onDraw(Canvas c) {
        cv = c;
        hits.clear();
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        u = Math.min(w, h) / 100f;
        c.drawColor(WHITE);
        if (m.view == Model.V_CAL) drawCalendar(w, h);
        else if (m.view == Model.V_CONV) drawConverter(w, h);
        else drawSettings(w, h);
    }

    private void drawHeader(int w, float hh, String title, String sub, String greg) {
        fill(0, 0, w, hh, 0, BLUE);
        center(title, w / 2f, hh * 0.30f, 6.6f * u, WHITE, true, w - 28 * u);
        if (sub != null) center(sub, w / 2f, hh * 0.52f, 3.7f * u, WHITE, false, w - 28 * u);
        if (greg != null) center(greg, w / 2f, hh * 0.69f, 3f * u, 0xDDFFFFFF, false, w - 28 * u);
    }

    private void drawCalendar(int w, int h) {
        float hh = 25 * u;
        drawHeader(w, hh, Model.monthName(m.id, m.he), Model.monthName(m.id, !m.he) + " " + (m.he ? String.valueOf(m.y) : HebCal.gematria(m.y % 1000)), gregSpan());
        // month arrows: they sit where the keys point (in Hebrew, "next" is on the left)
        float ny = hh * 0.40f, nr = 5.2f * u;
        float lx = 8 * u, rx = w - 8 * u;
        circle(lx, ny, nr, 0x30FFFFFF); center("‹", lx, ny - 0.3f * u, 8 * u, WHITE, true, 0);
        circle(rx, ny, nr, 0x30FFFFFF); center("›", rx, ny - 0.3f * u, 8 * u, WHITE, true, 0);
        hit(lx - nr, ny - nr, lx + nr, ny + nr, m.he ? Model.A_NEXT : Model.A_PREV, 0, 0);
        hit(rx - nr, ny - nr, rx + nr, ny + nr, m.he ? Model.A_PREV : Model.A_NEXT, 0, 0);
        // year row
        float yy = hh * 0.86f, bw = 6.5f * u, bh = 4.6f * u;
        center(String.valueOf(m.y), w / 2f, yy, 4.2f * u, WHITE, true, 0);
        float lb = w / 2f - 13 * u, rb = w / 2f + 13 * u;
        fill(lb - bw / 2, yy - bh / 2, lb + bw / 2, yy + bh / 2, 1.2f * u, 0x30FFFFFF);
        fill(rb - bw / 2, yy - bh / 2, rb + bw / 2, yy + bh / 2, 1.2f * u, 0x30FFFFFF);
        triangle(lb, yy, 1.5f * u, false, WHITE);
        triangle(rb, yy, 1.5f * u, true, WHITE);
        hit(lb - bw / 2, yy - bh / 2, lb + bw / 2, yy + bh / 2, m.upDir() > 0 ? Model.A_YDOWN : Model.A_YUP, 0, 0);
        hit(rb - bw / 2, yy - bh / 2, rb + bw / 2, yy + bh / 2, m.upDir() > 0 ? Model.A_YUP : Model.A_YDOWN, 0, 0);

        boolean land = w > h * 1.25f;
        float gx, gy, gw, gh, sx, sy, sw;
        float detailH = land ? 32 * u : 27 * u, barH = 9 * u, hintH = 5 * u;
        if (land) {
            gx = 2 * u; gy = hh + 2 * u; gw = w * 0.58f - 3 * u; gh = h - gy - 2 * u;
            sx = w * 0.58f + 1 * u; sy = gy; sw = w - sx - 2 * u;
        } else {
            gx = 2 * u; gy = hh + 1.5f * u; gw = w - 4 * u;
            gh = h - gy - (detailH + barH + hintH + 6 * u);
            sx = 2 * u; sy = gy + gh + 1.5f * u; sw = w - 4 * u;
        }
        drawGrid(gx, gy, gw, gh);
        drawDetail(sx, sy, sw, detailH);
        float by = sy + detailH + 1.6f * u;
        drawBar(sx, by, sw, barH);
        String hint = m.mode == Model.M_BROWSE ? m.s(Model.S_H_BROWSE) : m.mode == Model.M_DAY ? m.s(Model.S_H_DAY) : m.s(Model.S_H_BAR);
        center(hint, sx + sw / 2, by + barH + 2.8f * u, 2.8f * u, MUTE, false, sw);
    }

    private String gregSpan() {
        HebCal.Month[] ms = HebCal.monthsOf(m.y);
        int len = ms[HebCal.monthIdx(ms, m.id)].len, first = HebCal.hebToRD(m.y, m.id, 1);
        HebCal.GDate a = HebCal.rdToGreg(first), b = HebCal.rdToGreg(first + len - 1);
        if (a.y == b.y) return (a.m == b.m ? m.gm(a.m) : m.gm(a.m) + " – " + m.gm(b.m)) + " " + a.y;
        return m.gms(a.m) + " " + a.y + " – " + m.gms(b.m) + " " + b.y;
    }

    private void drawGrid(float gx, float gy, float gw, float gh) {
        float wdh = 5 * u, cw = gw / 7f, rh = (gh - wdh) / 6f;
        fill(gx, gy, gx + gw, gy + wdh, 1f * u, BLUE_L);
        for (int i = 0; i < 7; i++) {
            int col = m.he ? 6 - i : i;
            center(m.wdShort(i), gx + (col + 0.5f) * cw, gy + wdh / 2, 2.9f * u, i == 6 ? GREEN_D : BLUE, true, cw);
        }
        HebCal.Month[] ms = HebCal.monthsOf(m.y);
        int len = ms[HebCal.monthIdx(ms, m.id)].len;
        int first = HebCal.hebToRD(m.y, m.id, 1), sd = HebCal.dow(first);
        float unit = Math.min(cw, rh);
        float curL = 0, curT = 0; boolean haveCur = false;
        for (int i = 0; i < 42; i++) {
            int d = i - sd + 1;
            if (d < 1 || d > len) continue;
            int col = m.he ? 6 - (i % 7) : i % 7, row = i / 7;
            float l = gx + col * cw, t = gy + wdh + row * rh;
            int rd = first + d - 1;
            boolean today = rd == m.todayRD, sat = i % 7 == 6;
            fill(l, t, l + cw, t + rh, 0, today ? GREEN : sat ? GREEN_L : WHITE);
            stroke(l, t, l + cw, t + rh, 0, GRID, 0.2f * u);
            center(m.dayLabel(d), l + cw / 2, t + rh * 0.42f, unit * 0.36f, today ? WHITE : INK, true, cw - 0.6f * u);
            HebCal.GDate g = HebCal.rdToGreg(rd);
            String gs = g.d == 1 ? g.d + " " + m.gms(g.m) : String.valueOf(g.d);
            center(gs, l + cw / 2, t + rh * 0.71f, unit * 0.2f, today ? 0xE6FFFFFF : MUTE, false, cw);
            List<HebCal.Hol> hs = m.holidays(m.y, m.id, d, i % 7);
            if (!hs.isEmpty()) {
                boolean major = false;
                for (HebCal.Hol x : hs) if (x.t.equals("major")) major = true;
                circle(l + cw / 2, t + rh * 0.89f, Math.max(0.5f * u, unit * 0.045f), today ? WHITE : major ? GREEN : BLUE);
            }
            if (d == m.sel) {
                if (m.mode == Model.M_DAY) { curL = l; curT = t; haveCur = true; }
                else stroke(l + 0.3f * u, t + 0.3f * u, l + cw - 0.3f * u, t + rh - 0.3f * u, 0, BLUE, 0.5f * u);
            }
            hit(l, t, l + cw, t + rh, Model.A_CELL, d, 0);
        }
        if (haveCur) {
            stroke(curL - 0.2f * u, curT - 0.2f * u, curL + cw + 0.2f * u, curT + rh + 0.2f * u, 0.6f * u, GLOW, 2.2f * u);
            stroke(curL, curT, curL + cw, curT + rh, 0.4f * u, BLUE, 0.9f * u);
        }
    }

    private void drawDetail(float x, float y, float w, float h) {
        fill(x, y, x + w, y + h, 1.8f * u, BLUE_L);
        boolean rtl = m.he;
        fill(rtl ? x + w - 0.8f * u : x, y, rtl ? x + w : x + 0.8f * u, y + h, 0, GREEN);
        float tx = rtl ? x + w - 3f * u : x + 3f * u, maxW = w - 6f * u;
        Paint.Align al = rtl ? Paint.Align.RIGHT : Paint.Align.LEFT;
        int rd = m.selRD(), wd = HebCal.dow(rd);
        text(m.hebStr(m.y, m.id, m.sel, m.he), tx, y + 4f * u, 4.6f * u, BLUE_D, true, al, maxW);
        text(m.gregStr(HebCal.rdToGreg(rd), wd), tx, y + 8.4f * u, 3.3f * u, INK, false, al, maxW);
        text(m.hebStr(m.y, m.id, m.sel, !m.he), tx, y + 12f * u, 3.3f * u, INK, false, al, maxW);

        List<HebCal.Hol> hs = m.holidays(m.y, m.id, m.sel, wd);
        float cx = tx, cy = y + 16.8f * u, chipH = 4.2f * u, pad = 1.5f * u, size = 2.9f * u;
        int n = hs.size() + (rd == m.todayRD ? 1 : 0);
        for (int i = 0; i < n; i++) {
            boolean isToday = rd == m.todayRD && i == 0;
            HebCal.Hol hol = isToday ? null : hs.get(i - (rd == m.todayRD ? 1 : 0));
            String label = isToday ? m.s(Model.S_TODAY) : m.holName(hol);
            float cwid = textWidth(label, size, false) + 2 * pad;
            if (cwid > maxW) cwid = maxW;
            float l = rtl ? cx - cwid : cx;
            if (rtl ? l < x + 2f * u : l + cwid > x + w - 2f * u) {
                cx = tx; cy += chipH + 1f * u; l = rtl ? cx - cwid : cx;
            }
            if (cy + chipH / 2 > y + h) break;
            int bg, fg = WHITE;
            if (isToday) { bg = WHITE; fg = GREEN_D; }
            else if (hol.t.equals("major")) bg = GREEN;
            else if (hol.t.equals("fast")) bg = BLUE_D;
            else if (hol.t.equals("rc")) { bg = CHIP_RC; fg = BLUE_D; }
            else bg = BLUE;
            fill(l, cy - chipH / 2, l + cwid, cy + chipH / 2, chipH / 2, bg);
            if (isToday) stroke(l, cy - chipH / 2, l + cwid, cy + chipH / 2, chipH / 2, GREEN, 0.25f * u);
            center(label, l + cwid / 2, cy, size, fg, false, cwid - pad);
            cx = rtl ? l - 1f * u : l + cwid + 1f * u;
        }
    }

    private void drawBar(float x, float y, float w, float h) {
        String[] names = {m.s(Model.S_TODAY), m.s(Model.S_CONVERT), m.s(Model.S_SETTINGS)};
        int[] acts = {Model.A_TODAY, Model.A_CONV, Model.A_SET};
        float gap = 1.6f * u, bw = (w - 2 * gap) / 3f;
        for (int j = 0; j < 3; j++) {
            int pos = m.he ? 2 - j : j;
            float l = x + pos * (bw + gap);
            button(l, y, l + bw, y + h, names[j], j == 0 ? GREEN : BLUE_L, j == 0 ? WHITE : BLUE_D,
                    m.mode == Model.M_BAR && m.bar == j, acts[j], 0);
        }
    }

    // ------------------------------------------------------------------ converter
    private void drawSubHeader(int w, float hh, String title) {
        fill(0, 0, w, hh, 0, BLUE);
        center(title, w / 2f, hh / 2f, 5.6f * u, WHITE, true, w - 28 * u);
        float bx = m.he ? w - 8 * u : 8 * u;
        circle(bx, hh / 2f, 4.6f * u, 0x30FFFFFF);
        center(m.he ? "›" : "‹", bx, hh / 2f - 0.3f * u, 7 * u, WHITE, true, 0);
        hit(bx - 5 * u, 0, bx + 5 * u, hh, Model.A_BACK, 0, 0);
    }

    private void drawConverter(int w, int h) {
        float save = u;
        u = Math.min(u, h / 118f);
        float hh = 14 * u;
        drawSubHeader(w, hh, m.s(Model.S_CONVTITLE));
        float cw = Math.min(w - 6 * u, 115 * u), left = (w - cw) / 2f, y = hh + 3 * u;
        // direction button
        float mh = 10 * u;
        fill(left, y, left + cw, y + mh, 1.6f * u, BLUE_L);
        center((m.g2h ? m.s(Model.S_G2H) : m.s(Model.S_H2G)) + "  ↔", left + cw / 2, y + mh / 2, 4f * u, BLUE_D, true, cw - 3 * u);
        if (m.cf == 0) focusRing(left, y, left + cw, y + mh, 1.6f * u);
        hit(left, y, left + cw, y + mh, Model.A_TOGGLE, 0, 0);
        y += mh + 2.5f * u;
        // spinners
        String[] vals, labs = {m.s(Model.S_DAY), m.s(Model.S_MONTH), m.s(Model.S_YEAR)};
        if (m.g2h) vals = new String[]{String.valueOf(m.sd), m.gm(m.sm), String.valueOf(m.sy)};
        else vals = new String[]{m.dayLabel(m.sd), HebMonth(m.sid), String.valueOf(m.sy)};
        float gap = 2 * u, unitW = (cw - 2 * gap) / 3.9f;
        float[] ws = {unitW, unitW * 1.6f, unitW * 1.3f};
        float sh = 32 * u;
        for (int j = 0; j < 3; j++) {
            int pos = m.he ? 2 - j : j;
            float xl = left;
            for (int q = 0; q < pos; q++) xl += ws[m.he ? 2 - q : q] + gap;
            float xr = xl + ws[j];
            boolean foc = m.cf == j + 1;
            fill(xl, y, xr, y + sh, 1.6f * u, foc ? BLUE_L : WHITE);
            stroke(xl, y, xr, y + sh, 1.6f * u, foc ? BLUE : GRID, foc ? 0.5f * u : 0.35f * u);
            if (foc) focusRing(xl, y, xr, y + sh, 1.6f * u);
            center(labs[j], (xl + xr) / 2, y + 3.4f * u, 2.6f * u, MUTE, false, ws[j]);
            triangle((xl + xr) / 2, y + 9.5f * u, 2f * u, true, BLUE);
            center(vals[j], (xl + xr) / 2, y + 16.5f * u, 5.4f * u, INK, true, ws[j] - 1.5f * u);
            triangle((xl + xr) / 2, y + 24 * u, 2f * u, false, BLUE);
            hit(xl, y, xr, y + sh, Model.A_FIELD, j + 1, 0); // added first: later (more specific) hits win
            hit(xl, y + 5.5f * u, xr, y + 13 * u, Model.A_ADJ, j + 1, 1);
            hit(xl, y + 20 * u, xr, y + sh, Model.A_ADJ, j + 1, -1);
        }
        y += sh + 2.5f * u;
        // result
        int rd = m.convRD();
        HebCal.HDate hd = HebCal.rdToHeb(rd);
        HebCal.GDate gd = HebCal.rdToGreg(rd);
        int wd = HebCal.dow(rd);
        String r1, r2;
        if (m.g2h) { r1 = m.hebStr(hd.y, hd.id, hd.d, m.he); r2 = m.hebStr(hd.y, hd.id, hd.d, !m.he); }
        else { r1 = m.gregStr(gd, wd); r2 = m.wd(wd); }
        StringBuilder hs = new StringBuilder();
        for (HebCal.Hol x : m.holidays(hd.y, hd.id, hd.d, wd)) { if (hs.length() > 0) hs.append("  ·  "); hs.append(m.holName(x)); }
        float rh = 28 * u;
        fill(left, y, left + cw, y + rh, 2f * u, GREEN);
        center(m.s(Model.S_RESULT), left + cw / 2, y + 3.4f * u, 2.6f * u, 0xD9FFFFFF, false, 0);
        center(r1, left + cw / 2, y + 10.5f * u, 6f * u, WHITE, true, cw - 4 * u);
        center(r2, left + cw / 2, y + 17.5f * u, 3.8f * u, 0xF2FFFFFF, false, cw - 4 * u);
        if (hs.length() > 0) center(hs.toString(), left + cw / 2, y + 23.5f * u, 3f * u, 0xE6FFFFFF, false, cw - 4 * u);
        y += rh + 2.5f * u;
        button(left, y, left + cw, y + 10 * u, m.s(Model.S_SHOW), BLUE, WHITE, m.cf == 4, Model.A_SHOW, 0);
        center(m.s(Model.S_H_CONV), w / 2f, h - 3.5f * u, 2.8f * u, MUTE, false, w - 4 * u);
        u = save;
    }

    private String HebMonth(String id) { return Model.monthName(id, m.he); }

    // ------------------------------------------------------------------- settings
    private void drawSettings(int w, int h) {
        float save = u;
        u = Math.min(u, h / 70f);
        float hh = 14 * u;
        drawSubHeader(w, hh, m.s(Model.S_SETTITLE));
        String[] labels = {m.s(Model.S_LANG), m.s(Model.S_HOL), m.s(Model.S_UD)};
        String[] vals = {m.he ? "עברית" : "English", m.israel ? m.s(Model.S_ISR) : m.s(Model.S_DIA),
                m.invY ? m.s(Model.S_UD1) : m.s(Model.S_UD0)};
        float cw = Math.min(w - 6 * u, 115 * u), left = (w - cw) / 2f, y = hh + 3 * u, rh = 12 * u;
        for (int i = 0; i < 3; i++) {
            boolean foc = m.setIdx == i;
            fill(left, y, left + cw, y + rh, 1.8f * u, foc ? BLUE_L : WHITE);
            stroke(left, y, left + cw, y + rh, 1.8f * u, foc ? BLUE : GRID, foc ? 0.5f * u : 0.35f * u);
            if (foc) focusRing(left, y, left + cw, y + rh, 1.8f * u);
            Paint.Align a1 = m.he ? Paint.Align.RIGHT : Paint.Align.LEFT, a2 = m.he ? Paint.Align.LEFT : Paint.Align.RIGHT;
            text(labels[i], m.he ? left + cw - 3 * u : left + 3 * u, y + rh / 2, 4f * u, INK, false, a1, cw * 0.45f);
            text(vals[i], m.he ? left + 3 * u : left + cw - 3 * u, y + rh / 2, 4f * u, GREEN_D, true, a2, cw * 0.5f);
            hit(left, y, left + cw, y + rh, Model.A_SETROW, i, 0);
            y += rh + 2.5f * u;
        }
        center(m.s(Model.S_H_SET), w / 2f, h - 3.5f * u, 2.8f * u, MUTE, false, w - 4 * u);
        u = save;
    }

    // ----------------------------------------------------------------------- input
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int k;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP: k = Model.UP; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: k = Model.DOWN; break;
            case KeyEvent.KEYCODE_DPAD_LEFT: k = Model.LEFT; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: k = Model.RIGHT; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A: k = Model.OK; break;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_B: k = Model.BACK; break;
            case KeyEvent.KEYCODE_PAGE_UP: k = Model.PGUP; break;
            case KeyEvent.KEYCODE_PAGE_DOWN: k = Model.PGDN; break;
            case KeyEvent.KEYCODE_T: k = Model.KT; break;
            case KeyEvent.KEYCODE_C: k = Model.KC; break;
            case KeyEvent.KEYCODE_S: k = Model.KS; break;
            default: return super.onKeyDown(keyCode, event);
        }
        boolean handled = m.key(k);
        if (handled) invalidate();
        return handled; // an unhandled BACK falls through and closes the app
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getAction();
        if (a == MotionEvent.ACTION_DOWN) return true;
        if (a == MotionEvent.ACTION_UP) {
            float x = e.getX(), y = e.getY();
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit ht = hits.get(i);
                if (ht.r.contains(x, y)) { m.act(ht.a, ht.arg, ht.arg2); invalidate(); break; }
            }
            return true;
        }
        return super.onTouchEvent(e);
    }
}
