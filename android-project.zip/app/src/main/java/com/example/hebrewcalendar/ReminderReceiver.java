package com.example.hebrewcalendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires when a reminder alarm goes off: shows the notification and schedules the next occurrence. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getData() == null) return;
        long id;
        try { id = Long.parseLong(intent.getData().getLastPathSegment()); } catch (NumberFormatException ex) { return; }
        EventStore store = Reminders.load(context);
        EventStore.Event e = store.find(id);
        if (e == null) return; // deleted in the meantime
        int rd = intent.getIntExtra("rd", Reminders.todayRD());
        Reminders.notifyEvent(context, e, rd);
        Reminders.schedule(context, store, e); // yearly events: arm the next one
    }
}
