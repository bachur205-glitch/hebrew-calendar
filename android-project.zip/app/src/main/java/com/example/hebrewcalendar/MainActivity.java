package com.example.hebrewcalendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.format.DateFormat;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity implements Model.Host {
    private Model model;
    private CalView view;
    private EventStore store;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Reminders.ensureChannel(this);
        store = Reminders.load(this);
        store.onChange = new Runnable() {
            @Override public void run() {
                Reminders.save(MainActivity.this, store);
                Reminders.rescheduleAll(MainActivity.this, store);
            }
        };
        model = new Model(Reminders.todayRD(), store);
        model.host = this;
        String lang = Locale.getDefault().getLanguage();
        model.he = Reminders.prefs(this).getBoolean("he", lang.equals("he") || lang.equals("iw"));
        model.israel = Reminders.prefs(this).getBoolean("israel", false);
        model.invY = Reminders.prefs(this).getBoolean("invY", false);
        model.onSettingsChanged = new Runnable() {
            @Override public void run() {
                Reminders.prefs(MainActivity.this).edit().putBoolean("he", model.he).putBoolean("israel", model.israel)
                        .putBoolean("invY", model.invY).apply();
            }
        };
        view = new CalView(this, model);
        setContentView(view);
        view.requestFocus();
        handle(getIntent());
        Reminders.rescheduleAll(this, store);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
        view.invalidate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        model.todayRD = Reminders.todayRD();
        view.invalidate();
    }

    // ------------------------------------------------- calendar intents from other apps
    private static int rdFromMillis(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        return HebCal.gregToRD(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    private void handle(Intent in) {
        if (in == null) return;
        String action = in.getAction();
        int rd = in.getIntExtra("rd", Integer.MIN_VALUE);
        if (rd != Integer.MIN_VALUE) { // tapped a reminder notification
            model.showDay(rd);
            return;
        }
        if (Intent.ACTION_VIEW.equals(action) && in.getData() != null) {
            Uri d = in.getData();
            if ("com.android.calendar".equals(d.getHost())) { // content://com.android.calendar/time/<millis>
                long ms = -1;
                try { ms = Long.parseLong(d.getLastPathSegment()); } catch (NumberFormatException ex) { ms = in.getLongExtra("beginTime", -1); }
                if (ms > 0) model.showDate(rdFromMillis(ms));
            }
        } else if (Intent.ACTION_INSERT.equals(action) || Intent.ACTION_EDIT.equals(action)) { // "add an event" from another app
            long begin = in.getLongExtra("beginTime", -1);
            int day = begin > 0 ? rdFromMillis(begin) : Reminders.todayRD();
            int minutes = -1;
            if (begin > 0 && !in.getBooleanExtra("allDay", false)) {
                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(begin);
                minutes = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
            }
            model.newEventFor(day, in.getStringExtra("title"), minutes);
        }
    }

    // ------------------------------------------------------------ Model.Host
    @Override
    public void promptTitle(String current) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(current);
        input.setSelection(input.getText().length());
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(model.s(Model.S_TITLE))
                .setView(input)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        model.setTitle(input.getText().toString());
                        view.invalidate();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    @Override
    public void promptTime(int minutes) {
        new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override public void onTimeSet(TimePicker picker, int hour, int minute) {
                model.setTime(hour * 60 + minute);
                view.invalidate();
            }
        }, minutes / 60, minutes % 60, DateFormat.is24HourFormat(this)).show();
    }

    @Override
    public void notifyPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }
}
