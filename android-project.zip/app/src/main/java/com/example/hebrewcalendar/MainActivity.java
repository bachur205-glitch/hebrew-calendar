package com.example.hebrewcalendar;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;

import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private Model model;
    private CalView view;
    private SharedPreferences prefs;

    static int todayRD() {
        Calendar c = Calendar.getInstance();
        return HebCal.gregToRD(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("hebcal", MODE_PRIVATE);
        model = new Model(todayRD());
        String lang = Locale.getDefault().getLanguage();
        model.he = prefs.getBoolean("he", lang.equals("he") || lang.equals("iw"));
        model.israel = prefs.getBoolean("israel", false);
        model.invY = prefs.getBoolean("invY", false);
        model.onSettingsChanged = new Runnable() {
            @Override public void run() {
                prefs.edit().putBoolean("he", model.he).putBoolean("israel", model.israel).putBoolean("invY", model.invY).apply();
            }
        };
        view = new CalView(this, model);
        setContentView(view);
        view.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        model.todayRD = todayRD();
        view.invalidate();
    }
}
