package com.example.hebrewcalendar;

import java.util.List;

/** All app state and D-pad logic. Pure Java (no Android classes) so it can be unit tested anywhere. */
final class Model {
    // keys
    static final int UP = 1, DOWN = 2, LEFT = 3, RIGHT = 4, OK = 5, BACK = 6, PGUP = 7, PGDN = 8, KT = 9, KC = 10, KS = 11;
    // views and modes
    static final int V_CAL = 0, V_CONV = 1, V_SET = 2;
    static final int M_BROWSE = 0, M_DAY = 1, M_BAR = 2;
    // touch / button actions
    static final int A_PREV = 1, A_NEXT = 2, A_YUP = 3, A_YDOWN = 4, A_CELL = 5, A_TODAY = 6, A_CONV = 7, A_SET = 8,
            A_BACK = 9, A_TOGGLE = 10, A_FIELD = 11, A_ADJ = 12, A_SHOW = 13, A_SETROW = 14;

    static final int MINY = 3762, MAXY = 9999;

    // settings
    boolean he = false, israel = false, invY = false;
    Runnable onSettingsChanged;

    // calendar state
    int view = V_CAL, mode = M_BROWSE, bar = 0, setIdx = 0;
    int y; String id; int sel;
    int todayRD;

    // converter state
    boolean g2h = true; int cf = 1;
    int sy, sm, sd; String sid = "Tishri";

    Model(int todayRD) { this.todayRD = todayRD; goRD(todayRD); }

    void goRD(int rd) { HebCal.HDate h = HebCal.rdToHeb(rd); y = h.y; id = h.id; sel = h.d; }

    // ------------------------------------------------------------------ helpers
    static int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
    static int wrap(int v, int a, int b) { return v > b ? a : v < a ? b : v; }
    static String fixId(int y, String id) {
        boolean leap = HebCal.isLeap(y);
        if (leap && id.equals("Adar")) return "AdarII";
        if (!leap && (id.equals("AdarI") || id.equals("AdarII"))) return "Adar";
        return id;
    }
    int upDir() { return invY ? -1 : 1; }
    int visualDir(int k) { int s = k == RIGHT ? 1 : -1; return he ? -s : s; }
    int selRD() { return HebCal.hebToRD(y, id, sel); }

    // --------------------------------------------------------------- navigation
    void shiftMonth(int delta) {
        HebCal.Month[] ms = HebCal.monthsOf(y);
        int i = HebCal.monthIdx(ms, id) + delta;
        if (i < 0) { if (y <= MINY) return; y--; ms = HebCal.monthsOf(y); i = ms.length - 1; }
        else if (i >= ms.length) { if (y >= MAXY) return; y++; ms = HebCal.monthsOf(y); i = 0; }
        id = ms[i].id; sel = Math.min(sel, ms[i].len);
    }
    void shiftYear(int delta) {
        y = clamp(y + delta, MINY, MAXY);
        id = fixId(y, id);
        sel = Math.min(sel, HebCal.monthLen(y, id));
    }
    void shiftDay(int delta) {
        HebCal.HDate h = HebCal.rdToHeb(selRD() + delta);
        if (h.y < MINY || h.y > MAXY) return;
        y = h.y; id = h.id; sel = h.d;
    }

    // ---------------------------------------------------------------- converter
    void convInit(int rd) {
        if (g2h) {
            HebCal.GDate g = HebCal.rdToGreg(rd);
            sy = clamp(g.y, 1, 9999); sm = g.m; sd = g.d;
        } else {
            HebCal.HDate h = HebCal.rdToHeb(rd);
            if (h.y < MINY) { h.y = MINY; h.id = "Tishri"; h.d = 1; }
            if (h.y > MAXY) { h.y = MAXY; h.id = "Elul"; h.d = 29; }
            sy = h.y; sid = h.id; sd = h.d;
        }
    }
    int convRD() { return g2h ? HebCal.gregToRD(sy, sm, sd) : HebCal.hebToRD(sy, sid, sd); }
    void convAdjust(int f, int delta) {
        if (g2h) {
            if (f == 1) sd = wrap(sd + delta, 1, HebCal.gregDays(sy, sm));
            else if (f == 2) { sm = wrap(sm + delta, 1, 12); sd = Math.min(sd, HebCal.gregDays(sy, sm)); }
            else if (f == 3) { sy = clamp(sy + delta, 1, 9999); sd = Math.min(sd, HebCal.gregDays(sy, sm)); }
        } else {
            HebCal.Month[] ms = HebCal.monthsOf(sy);
            if (f == 1) sd = wrap(sd + delta, 1, ms[HebCal.monthIdx(ms, sid)].len);
            else if (f == 2) {
                int i = wrap(HebCal.monthIdx(ms, sid) + delta, 0, ms.length - 1);
                sid = ms[i].id; sd = Math.min(sd, ms[i].len);
            } else if (f == 3) {
                sy = clamp(sy + delta, MINY, MAXY); sid = fixId(sy, sid);
                sd = Math.min(sd, HebCal.monthLen(sy, sid));
            }
        }
    }
    void convToggle() { int rd = convRD(); g2h = !g2h; convInit(rd); }
    void openConv() { cf = 1; convInit(selRD()); view = V_CONV; }
    void showInCal() { goRD(convRD()); view = V_CAL; mode = M_DAY; }
    void goToday() { goRD(todayRD); mode = M_DAY; }
    void openSettings() { view = V_SET; setIdx = 0; }

    void changeSetting(int i) {
        if (i == 0) he = !he; else if (i == 1) israel = !israel; else invY = !invY;
        if (onSettingsChanged != null) onSettingsChanged.run();
    }

    // -------------------------------------------------------------------- input
    /** Returns true when the key was used. BACK returns false when the app should close. */
    boolean key(int k) {
        if (view == V_CAL) {
            if (k == KT) { goToday(); return true; }
            if (k == KC) { openConv(); return true; }
            if (k == KS) { openSettings(); return true; }
            return keyCal(k);
        }
        return view == V_CONV ? keyConv(k) : keySettings(k);
    }

    private boolean keyCal(int k) {
        if (mode == M_BROWSE) {
            if (k == LEFT || k == RIGHT) shiftMonth(visualDir(k));
            else if (k == UP) shiftYear(upDir());
            else if (k == DOWN) shiftYear(-upDir());
            else if (k == PGUP) shiftYear(10 * upDir());
            else if (k == PGDN) shiftYear(-10 * upDir());
            else if (k == OK) mode = M_DAY;
            else return false;
        } else if (mode == M_DAY) {
            int len = HebCal.monthLen(y, id);
            if (k == LEFT || k == RIGHT) shiftDay(visualDir(k));
            else if (k == UP) { if (sel > 7) sel -= 7; else shiftDay(-7); }
            else if (k == DOWN) { if (sel + 7 <= len) sel += 7; else { mode = M_BAR; bar = 0; } }
            else if (k == PGUP) shiftMonth(1);
            else if (k == PGDN) shiftMonth(-1);
            else if (k == OK) openConv();
            else if (k == BACK) mode = M_BROWSE;
            else return false;
        } else {
            if (k == LEFT || k == RIGHT) bar = clamp(bar + (he ? -1 : 1) * (k == RIGHT ? 1 : -1), 0, 2);
            else if (k == UP) mode = M_DAY;
            else if (k == OK) { if (bar == 0) goToday(); else if (bar == 1) openConv(); else openSettings(); }
            else if (k == BACK) mode = M_BROWSE;
            else return false;
        }
        return true;
    }

    private boolean keyConv(int k) {
        if (k == BACK) { view = V_CAL; return true; }
        if (k == LEFT || k == RIGHT) { cf = clamp(cf + (he ? -1 : 1) * (k == RIGHT ? 1 : -1), 0, 4); return true; }
        if (k == UP || k == DOWN || k == PGUP || k == PGDN) {
            int d = (k == UP || k == PGUP) ? 1 : -1;
            if (cf == 0) convToggle();
            else if (cf <= 3) convAdjust(cf, (k == PGUP || k == PGDN) && cf == 3 ? d * 10 : d);
            return true;
        }
        if (k == OK) { if (cf == 0) convToggle(); else showInCal(); return true; }
        return false;
    }

    private boolean keySettings(int k) {
        if (k == BACK) { view = V_CAL; return true; }
        if (k == UP) setIdx = clamp(setIdx - 1, 0, 2);
        else if (k == DOWN) setIdx = clamp(setIdx + 1, 0, 2);
        else if (k == LEFT || k == RIGHT || k == OK) changeSetting(setIdx);
        else return false;
        return true;
    }

    /** Touch / on-screen button actions. */
    void act(int a, int arg, int arg2) {
        switch (a) {
            case A_PREV: shiftMonth(-1); break;
            case A_NEXT: shiftMonth(1); break;
            case A_YUP: shiftYear(1); break;
            case A_YDOWN: shiftYear(-1); break;
            case A_CELL: sel = arg; mode = M_DAY; break;
            case A_TODAY: goToday(); break;
            case A_CONV: openConv(); break;
            case A_SET: openSettings(); break;
            case A_BACK: view = V_CAL; break;
            case A_TOGGLE: cf = 0; convToggle(); break;
            case A_FIELD: cf = arg; break;
            case A_ADJ: cf = arg; convAdjust(arg, arg2); break;
            case A_SHOW: showInCal(); break;
            case A_SETROW: setIdx = arg; changeSetting(arg); break;
            default: break;
        }
    }

    // --------------------------------------------------------------------- text
    static final int S_TODAY = 0, S_CONVERT = 1, S_SETTINGS = 2, S_H_BROWSE = 3, S_H_DAY = 4, S_H_BAR = 5, S_H_CONV = 6,
            S_H_SET = 7, S_G2H = 8, S_H2G = 9, S_DAY = 10, S_MONTH = 11, S_YEAR = 12, S_SHOW = 13, S_CONVTITLE = 14,
            S_SETTITLE = 15, S_LANG = 16, S_HOL = 17, S_DIA = 18, S_ISR = 19, S_UD = 20, S_UD0 = 21, S_UD1 = 22,
            S_RESULT = 23, S_CANDLE = 24;
    private static final String[] EN = {
        "Today", "Convert", "Settings",
        "← → Month   ↑ ↓ Year   OK Pick a day",
        "Arrows Move   OK Convert   Back Exit",
        "← → Choose   OK Open   ↑ Back to days",
        "← → Field   ↑ ↓ Change   OK Show   Back",
        "↑ ↓ Select   ← → or OK Change   Back",
        "Gregorian → Hebrew", "Hebrew → Gregorian", "DAY", "MONTH", "YEAR", "Show in calendar", "Date Converter",
        "Settings", "Language", "Holidays", "Diaspora", "Israel", "Up / Down keys", "Up = next year", "Up = previous year",
        "RESULT", "day"
    };
    private static final String[] HE = {
        "היום", "המרה", "הגדרות",
        "← → חודש   ↑ ↓ שנה   OK בחירת יום",
        "חצים ניווט   OK המרה   חזרה",
        "← → בחירה   OK פתיחה   ↑ לימים",
        "← → שדה   ↑ ↓ שינוי   OK הצגה   חזרה",
        "↑ ↓ בחירה   ← → או OK שינוי   חזרה",
        "לועזי → עברי", "עברי → לועזי",
        "יום", "חודש", "שנה", "הצג בלוח",
        "המרת תאריכים", "הגדרות", "שפה",
        "חגים", "חו״ל", "ישראל",
        "מקשי למעלה / למטה",
        "למעלה = שנה הבאה",
        "למעלה = שנה קודמת",
        "תוצאה", "נר"
    };
    String s(int i) { return he ? HE[i] : EN[i]; }

    static final String[] WD_EN = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Shabbat"};
    static final String[] WD_HE = {"ראשון", "שני", "שלישי",
        "רביעי", "חמישי", "שישי", "שבת"};
    static final String[] WDS_EN = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static final String[] WDS_HE = {"א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"};
    static final String[] GM_EN = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
        "October", "November", "December"};
    static final String[] GM_HE = {"ינואר", "פברואר", "מרץ",
        "אפריל", "מאי", "יוני", "יולי",
        "אוגוסט", "ספטמבר", "אוקטובר",
        "נובמבר", "דצמבר"};
    static final String[] GMS_EN = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static final String[] GMS_HE = {"ינו׳", "פבר׳", "מרץ", "אפר׳",
        "מאי", "יוני", "יולי", "אוג׳", "ספט׳",
        "אוק׳", "נוב׳", "דצמ׳"};

    String wd(int i) { return he ? WD_HE[i] : WD_EN[i]; }
    String wdShort(int i) { return he ? WDS_HE[i] : WDS_EN[i]; }
    String gm(int m) { return he ? GM_HE[m - 1] : GM_EN[m - 1]; }
    String gms(int m) { return he ? GMS_HE[m - 1] : GMS_EN[m - 1]; }

    private static final String[][] MONTH = {
        {"Tishri", "Tishrei", "תשרי"}, {"Cheshvan", "Cheshvan", "חשוון"},
        {"Kislev", "Kislev", "כסלו"}, {"Tevet", "Tevet", "טבת"},
        {"Shevat", "Shevat", "שבט"}, {"Adar", "Adar", "אדר"},
        {"AdarI", "Adar I", "אדר א׳"}, {"AdarII", "Adar II", "אדר ב׳"},
        {"Nisan", "Nisan", "ניסן"}, {"Iyar", "Iyar", "אייר"},
        {"Sivan", "Sivan", "סיוון"}, {"Tammuz", "Tammuz", "תמוז"},
        {"Av", "Av", "אב"}, {"Elul", "Elul", "אלול"}
    };
    static String monthName(String id, boolean heb) {
        for (String[] m : MONTH) if (m[0].equals(id)) return heb ? m[2] : m[1];
        return id;
    }

    private static final String[][] HOL = {
        {"rh", "Rosh Hashana", "ראש השנה"},
        {"rh2", "Rosh Hashana II", "ראש השנה ב׳"},
        {"gedaliah", "Fast of Gedaliah", "צום גדליה"},
        {"yk", "Yom Kippur", "יום כיפור"},
        {"sukkot", "Sukkot", "סוכות"},
        {"sukkot2", "Sukkot II", "סוכות ב׳"},
        {"chm", "Chol HaMoed", "חול המועד"},
        {"hoshana", "Hoshana Rabba", "הושענא רבה"},
        {"shemini", "Shemini Atzeret", "שמיני עצרת"},
        {"shemini_st", "Shemini Atzeret / Simchat Torah", "שמיני עצרת / שמחת תורה"},
        {"simchat", "Simchat Torah", "שמחת תורה"},
        {"chanukah", "Chanukah", "חנוכה"},
        {"tevet10", "Fast of 10 Tevet", "עשרה בטבת"},
        {"tubishvat", "Tu BiShvat", "ט״ו בשבט"},
        {"purimkatan", "Purim Katan", "פורים קטן"},
        {"shushankatan", "Shushan Purim Katan", "שושן פורים קטן"},
        {"esther", "Fast of Esther", "תענית אסתר"},
        {"purim", "Purim", "פורים"},
        {"shushan", "Shushan Purim", "שושן פורים"},
        {"pesach", "Pesach", "פסח"},
        {"pesach2", "Pesach II", "פסח ב׳"},
        {"pesach7", "Pesach (7th day)", "שביעי של פסח"},
        {"pesach8", "Pesach (8th day)", "אחרון של פסח"},
        {"lag", "Lag BaOmer", "ל״ג בעומר"},
        {"shavuot", "Shavuot", "שבועות"},
        {"shavuot2", "Shavuot II", "שבועות ב׳"},
        {"tammuz17", "17 Tammuz", "י״ז בתמוז"},
        {"tisha", "Tisha B'Av", "תשעה באב"},
        {"tubav", "Tu B'Av", "ט״ו באב"},
        {"rc", "Rosh Chodesh", "ראש חודש"}
    };
    String holName(HebCal.Hol h) {
        String n = h.k;
        for (String[] x : HOL) if (x[0].equals(h.k)) { n = he ? x[2] : x[1]; break; }
        if (h.n > 0) n = n + " · " + s(S_CANDLE) + " " + (he ? HebCal.gematria(h.n) : String.valueOf(h.n));
        return n;
    }

    String dayLabel(int d) { return he ? HebCal.gematria(d) : String.valueOf(d); }
    String hebStr(int y, String id, int d, boolean heb) {
        if (heb) return HebCal.gematria(d) + " " + monthName(id, true) + " " + HebCal.gematria(y % 1000);
        return d + " " + monthName(id, false) + " " + y;
    }
    String gregStr(HebCal.GDate g, int wd) {
        if (he) return "יום " + WD_HE[wd] + ", " + g.d + " ב" + GM_HE[g.m - 1] + " " + g.y;
        return WD_EN[wd] + ", " + g.d + " " + GM_EN[g.m - 1] + " " + g.y;
    }
    List<HebCal.Hol> holidays(int y, String id, int d, int wd) { return HebCal.holidays(y, id, d, wd, israel); }
}
