package com.example.hebrewcalendar;

import java.util.ArrayList;
import java.util.List;

/** All app state and D-pad / soft-key logic. Pure Java (no Android classes) so it can be unit tested anywhere. */
final class Model {
    // keys
    static final int UP = 1, DOWN = 2, LEFT = 3, RIGHT = 4, OK = 5, BACK = 6, PGUP = 7, PGDN = 8, KT = 9, KC = 10, KS = 11,
            SOFTL = 12, SOFTR = 13, MENU = 14;
    // screens and calendar modes
    static final int V_CAL = 0, V_CONV = 1, V_SET = 2, V_DAY = 3, V_EDIT = 4, V_UP = 5;
    static final int M_BROWSE = 0, M_DAY = 1;
    // touch / on-screen actions
    static final int A_PREV = 1, A_NEXT = 2, A_YUP = 3, A_YDOWN = 4, A_CELL = 5, A_TOGGLE = 10, A_FIELD = 11, A_ADJ = 12,
            A_SHOW = 13, A_SETROW = 14, A_SOFTL = 15, A_SOFTR = 16, A_OK = 17, A_ROW = 18, A_MENUITEM = 19, A_MENUCLOSE = 20,
            A_BACK = 21;
    // editor rows
    static final int F_TITLE = 0, F_TIME = 1, F_REMIND = 2, F_REPEAT = 3, F_SAVE = 4, F_DELETE = 5;
    static final int MENU_ITEMS = 5;

    static final int MINY = 3762, MAXY = 9999;

    /** Things only the Android layer can do (dialogs, permissions). */
    interface Host {
        void promptTitle(String current);
        void promptTime(int minutes);
        void notifyPermission();
    }

    // settings
    boolean he = false, israel = false, invY = false, chabad = true;
    Runnable onSettingsChanged;

    final EventStore store;
    Host host;

    // calendar state
    int view = V_CAL, mode = M_BROWSE;
    int y; String id; int sel;
    int todayRD;
    boolean menuOpen; int menuIdx;

    // converter state
    boolean g2h = true; int cf = 1, setIdx = 0;
    int sy, sm, sd; String sid = "Tishri";

    // day screen
    int dayIdx, dayScroll; long pendingDelete;

    // editor
    EventStore.Event edit; boolean editNew; int editField, editReturn = V_CAL;

    // upcoming list
    static final class Up {
        final int rd; final EventStore.Event e;
        Up(int rd, EventStore.Event e) { this.rd = rd; this.e = e; }
    }
    final List<Up> up = new ArrayList<Up>();
    int upIdx, upScroll;

    Model(int todayRD, EventStore store) { this.todayRD = todayRD; this.store = store; goRD(todayRD); }

    void goRD(int rd) { HebCal.HDate h = HebCal.rdToHeb(rd); y = h.y; id = h.id; sel = h.d; }

    // ------------------------------------------------------------------ helpers
    static int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
    static int wrap(int v, int a, int b) { return v > b ? a : v < a ? b : v; }
    static String fixId(int y, String id) {
        boolean leap = HebCal.isLeap(y);
        if (leap && id.equals("Adar")) return "AdarII";
        if (!leap && (id.equals("AdarI") || id.equals("AdarII"))) return "Adar";
        return id;
    }
    int upDir() { return invY ? -1 : 1; }
    int visualDir(int k) { int s = k == RIGHT ? 1 : -1; return he ? -s : s; }
    int selRD() { return HebCal.hebToRD(y, id, sel); }
    List<EventStore.Event> dayEvents() { return store.on(selRD()); }

    // --------------------------------------------------------------- navigation
    void shiftMonth(int delta) {
        HebCal.Month[] ms = HebCal.monthsOf(y);
        int i = HebCal.monthIdx(ms, id) + delta;
        if (i < 0) { if (y <= MINY) return; y--; ms = HebCal.monthsOf(y); i = ms.length - 1; }
        else if (i >= ms.length) { if (y >= MAXY) return; y++; ms = HebCal.monthsOf(y); i = 0; }
        id = ms[i].id; sel = Math.min(sel, ms[i].len);
    }
    void shiftYear(int delta) {
        y = clamp(y + delta, MINY, MAXY);
        id = fixId(y, id);
        sel = Math.min(sel, HebCal.monthLen(y, id));
    }
    void shiftDay(int delta) {
        HebCal.HDate h = HebCal.rdToHeb(selRD() + delta);
        if (h.y < MINY || h.y > MAXY) return;
        y = h.y; id = h.id; sel = h.d;
    }

    // ----------------------------------------------------------- screen changes
    void goToday() { goRD(todayRD); view = V_CAL; mode = M_DAY; }
    void showDate(int rd) { goRD(rd); view = V_CAL; mode = M_DAY; }
    void showDay(int rd) { goRD(rd); openDay(); }
    void openDay() { view = V_DAY; dayIdx = 0; dayScroll = 0; pendingDelete = 0; }
    void openSettings() { view = V_SET; setIdx = 0; }
    void openConv() { cf = 1; convInit(selRD()); view = V_CONV; }
    void openUpcoming() {
        up.clear();
        for (int d = todayRD; d <= todayRD + 365 && up.size() < 80; d++) {
            for (EventStore.Event e : store.on(d)) up.add(new Up(d, e));
        }
        upIdx = 0; upScroll = 0; view = V_UP;
    }
    void changeSetting(int i) {
        if (i == 0) he = !he; else if (i == 1) israel = !israel; else if (i == 2) chabad = !chabad; else invY = !invY;
        if (onSettingsChanged != null) onSettingsChanged.run();
    }

    // ---------------------------------------------------------------- converter
    void convInit(int rd) {
        if (g2h) {
            HebCal.GDate g = HebCal.rdToGreg(rd);
            sy = clamp(g.y, 1, 9999); sm = g.m; sd = g.d;
        } else {
            HebCal.HDate h = HebCal.rdToHeb(rd);
            if (h.y < MINY) { h.y = MINY; h.id = "Tishri"; h.d = 1; }
            if (h.y > MAXY) { h.y = MAXY; h.id = "Elul"; h.d = 29; }
            sy = h.y; sid = h.id; sd = h.d;
        }
    }
    int convRD() { return g2h ? HebCal.gregToRD(sy, sm, sd) : HebCal.hebToRD(sy, sid, sd); }
    void convAdjust(int f, int delta) {
        if (g2h) {
            if (f == 1) sd = wrap(sd + delta, 1, HebCal.gregDays(sy, sm));
            else if (f == 2) { sm = wrap(sm + delta, 1, 12); sd = Math.min(sd, HebCal.gregDays(sy, sm)); }
            else if (f == 3) { sy = clamp(sy + delta, 1, 9999); sd = Math.min(sd, HebCal.gregDays(sy, sm)); }
        } else {
            HebCal.Month[] ms = HebCal.monthsOf(sy);
            if (f == 1) sd = wrap(sd + delta, 1, ms[HebCal.monthIdx(ms, sid)].len);
            else if (f == 2) {
                int i = wrap(HebCal.monthIdx(ms, sid) + delta, 0, ms.length - 1);
                sid = ms[i].id; sd = Math.min(sd, ms[i].len);
            } else if (f == 3) {
                sy = clamp(sy + delta, MINY, MAXY); sid = fixId(sy, sid);
                sd = Math.min(sd, HebCal.monthLen(sy, sid));
            }
        }
    }
    void convToggle() { int rd = convRD(); g2h = !g2h; convInit(rd); }
    void showInCal() { goRD(convRD()); view = V_CAL; mode = M_DAY; }

    // ------------------------------------------------------------------- events
    void addEvent() {
        edit = store.create(selRD());
        editNew = true; editField = F_TITLE; editReturn = view;
        view = V_EDIT;
    }
    void editEvent(EventStore.Event e) {
        edit = e.copy();
        editNew = false; editField = F_TITLE; editReturn = V_DAY;
        view = V_EDIT;
    }
    /** Used when another app asks us to create an event (INSERT intent). */
    void newEventFor(int rd, String title, int minutes) {
        goRD(rd);
        addEvent();
        editReturn = V_CAL;
        if (title != null) edit.title = title;
        edit.minutes = minutes;
    }
    void setTitle(String t) { if (edit != null) edit.title = t == null ? "" : t; }
    void setTime(int minutes) { if (edit != null) edit.minutes = clamp(minutes, 0, 1439); }
    int editRows() { return editNew ? 5 : 6; }

    private void stepTime(int dir) {
        int m = edit.minutes;
        if (m < 0) m = dir > 0 ? 9 * 60 : 23 * 60 + 45;
        else { m += dir * 15; if (m < 0 || m >= 1440) m = -1; }
        edit.minutes = m;
    }
    private void cycleRemind(int dir) {
        int[] r = EventStore.REMIND;
        int i = 0;
        for (int j = 0; j < r.length; j++) if (r[j] == edit.remind) i = j;
        edit.remind = r[wrap(i + dir, 0, r.length - 1)];
    }
    private void saveEdit() {
        edit.title = edit.title.trim();
        if (edit.title.length() == 0) edit.title = s(S_EVENT);
        store.save(edit);
        if (edit.remind >= 0 && host != null) host.notifyPermission();
        goRD(edit.rd);
        openDay();
        List<EventStore.Event> ev = dayEvents();
        for (int i = 0; i < ev.size(); i++) if (ev.get(i).id == edit.id) dayIdx = i;
    }
    private void deleteEdit() {
        store.delete(edit.id);
        openDay();
    }

    // -------------------------------------------------------------------- input
    /** Returns true when the key was used. BACK returns false when the app should close. */
    boolean key(int k) {
        switch (view) {
            case V_CAL: return keyCal(k);
            case V_DAY: return keyDay(k);
            case V_EDIT: return keyEdit(k);
            case V_UP: return keyUp(k);
            case V_CONV: return keyConv(k);
            default: return keySettings(k);
        }
    }

    String[] menuLabels() {
        return new String[]{s(S_TODAY), s(S_ADDEV), s(S_UPCOMING), s(S_CONVERT), s(S_SETTINGS)};
    }
    private void runMenu(int i) {
        menuOpen = false;
        if (i == 0) goToday();
        else if (i == 1) addEvent();
        else if (i == 2) openUpcoming();
        else if (i == 3) openConv();
        else openSettings();
    }

    private boolean keyCal(int k) {
        if (menuOpen) {
            if (k == UP) menuIdx = wrap(menuIdx - 1, 0, MENU_ITEMS - 1);
            else if (k == DOWN) menuIdx = wrap(menuIdx + 1, 0, MENU_ITEMS - 1);
            else if (k == OK) runMenu(menuIdx);
            else if (k == BACK || k == SOFTR || k == MENU) menuOpen = false;
            return true; // the menu swallows everything while it is open
        }
        if (k == SOFTR || k == MENU) { menuOpen = true; menuIdx = 0; return true; }
        if (k == SOFTL) { addEvent(); return true; }
        if (k == KT) { goToday(); return true; }
        if (k == KC) { openConv(); return true; }
        if (k == KS) { openSettings(); return true; }
        if (mode == M_BROWSE) {
            if (k == LEFT || k == RIGHT) shiftMonth(visualDir(k));
            else if (k == UP) shiftYear(upDir());
            else if (k == DOWN) shiftYear(-upDir());
            else if (k == PGUP) shiftYear(10 * upDir());
            else if (k == PGDN) shiftYear(-10 * upDir());
            else if (k == OK) mode = M_DAY;
            else return false;
        } else {
            if (k == LEFT || k == RIGHT) shiftDay(visualDir(k));
            else if (k == UP) shiftDay(-7);
            else if (k == DOWN) shiftDay(7);
            else if (k == PGUP) shiftMonth(1);
            else if (k == PGDN) shiftMonth(-1);
            else if (k == OK) openDay();
            else if (k == BACK) mode = M_BROWSE;
            else return false;
        }
        return true;
    }

    private boolean keyDay(int k) {
        List<EventStore.Event> ev = dayEvents();
        int n = ev.size();
        dayIdx = clamp(dayIdx, 0, n);
        if (k != SOFTR) pendingDelete = 0;
        if (k == LEFT || k == RIGHT) { shiftDay(visualDir(k)); dayIdx = 0; dayScroll = 0; }
        else if (k == UP) dayIdx = clamp(dayIdx - 1, 0, n);
        else if (k == DOWN) dayIdx = clamp(dayIdx + 1, 0, n);
        else if (k == OK) { if (dayIdx < n) editEvent(ev.get(dayIdx)); else addEvent(); }
        else if (k == SOFTL) addEvent();
        else if (k == SOFTR) {
            if (dayIdx < n) {
                EventStore.Event e = ev.get(dayIdx);
                if (pendingDelete == e.id) { store.delete(e.id); pendingDelete = 0; dayIdx = clamp(dayIdx, 0, n - 1); }
                else pendingDelete = e.id;
            } else { view = V_CAL; mode = M_DAY; }
        }
        else if (k == BACK) { view = V_CAL; mode = M_DAY; }
        else return false;
        return true;
    }

    private boolean keyEdit(int k) {
        if (k == BACK || k == SOFTR) { view = editReturn; return true; }
        if (k == SOFTL) { saveEdit(); return true; }
        if (k == UP) { editField = clamp(editField - 1, 0, editRows() - 1); return true; }
        if (k == DOWN) { editField = clamp(editField + 1, 0, editRows() - 1); return true; }
        if (k == LEFT || k == RIGHT) {
            int d = k == RIGHT ? 1 : -1;
            if (editField == F_TIME) stepTime(d);
            else if (editField == F_REMIND) cycleRemind(d);
            else if (editField == F_REPEAT) edit.yearly = !edit.yearly;
            return true;
        }
        if (k == OK) {
            switch (editField) {
                case F_TITLE: if (host != null) host.promptTitle(edit.title); break;
                case F_TIME: if (host != null) host.promptTime(edit.minutes < 0 ? 9 * 60 : edit.minutes); else stepTime(1); break;
                case F_REMIND: cycleRemind(1); break;
                case F_REPEAT: edit.yearly = !edit.yearly; break;
                case F_SAVE: saveEdit(); break;
                default: deleteEdit(); break;
            }
            return true;
        }
        return false;
    }

    private boolean keyUp(int k) {
        int n = up.size();
        if (k == BACK || k == SOFTR) { view = V_CAL; return true; }
        if (k == UP) upIdx = clamp(upIdx - 1, 0, Math.max(0, n - 1));
        else if (k == DOWN) upIdx = clamp(upIdx + 1, 0, Math.max(0, n - 1));
        else if (k == OK) {
            if (n == 0) return true;
            Up u = up.get(upIdx);
            goRD(u.rd);
            openDay();
            List<EventStore.Event> ev = dayEvents();
            for (int i = 0; i < ev.size(); i++) if (ev.get(i).id == u.e.id) dayIdx = i;
        }
        else return false;
        return true;
    }

    private boolean keyConv(int k) {
        if (k == BACK || k == SOFTR) { view = V_CAL; return true; }
        if (k == LEFT || k == RIGHT) { cf = clamp(cf + (he ? -1 : 1) * (k == RIGHT ? 1 : -1), 0, 4); return true; }
        if (k == UP || k == DOWN || k == PGUP || k == PGDN) {
            int d = (k == UP || k == PGUP) ? 1 : -1;
            if (cf == 0) convToggle();
            else if (cf <= 3) convAdjust(cf, (k == PGUP || k == PGDN) && cf == 3 ? d * 10 : d);
            return true;
        }
        if (k == OK) { if (cf == 0) convToggle(); else showInCal(); return true; }
        return false;
    }

    private boolean keySettings(int k) {
        if (k == BACK || k == SOFTR) { view = V_CAL; return true; }
        if (k == UP) setIdx = clamp(setIdx - 1, 0, 3);
        else if (k == DOWN) setIdx = clamp(setIdx + 1, 0, 3);
        else if (k == LEFT || k == RIGHT || k == OK) changeSetting(setIdx);
        else return false;
        return true;
    }

    /** Touch / on-screen button actions. */
    void act(int a, int arg, int arg2) {
        switch (a) {
            case A_PREV: if (view == V_DAY) { shiftDay(-1); dayIdx = 0; dayScroll = 0; } else shiftMonth(-1); break;
            case A_NEXT: if (view == V_DAY) { shiftDay(1); dayIdx = 0; dayScroll = 0; } else shiftMonth(1); break;
            case A_YUP: shiftYear(1); break;
            case A_YDOWN: shiftYear(-1); break;
            case A_CELL:
                if (mode == M_DAY && sel == arg) openDay(); // second tap on the same day opens it
                else { sel = arg; mode = M_DAY; }
                break;
            case A_TOGGLE: cf = 0; convToggle(); break;
            case A_FIELD: cf = arg; break;
            case A_ADJ: cf = arg; convAdjust(arg, arg2); break;
            case A_SHOW: showInCal(); break;
            case A_SETROW: setIdx = arg; changeSetting(arg); break;
            case A_SOFTL: key(SOFTL); break;
            case A_SOFTR: key(SOFTR); break;
            case A_OK: key(OK); break;
            case A_BACK: key(BACK); break;
            case A_MENUITEM: menuIdx = arg; runMenu(arg); break;
            case A_MENUCLOSE: menuOpen = false; break;
            case A_ROW:
                if (view == V_DAY) { dayIdx = arg; key(OK); }
                else if (view == V_EDIT) { editField = arg; key(OK); }
                else if (view == V_UP) { upIdx = arg; key(OK); }
                break;
            default: break;
        }
    }

    // --------------------------------------------------------------- soft keys
    String softL() {
        switch (view) {
            case V_CAL: return menuOpen ? "" : s(S_PLUSEV);
            case V_DAY: return s(S_PLUSEV);
            case V_EDIT: return s(S_SAVE);
            default: return "";
        }
    }
    String softC() {
        switch (view) {
            case V_CAL: return menuOpen ? s(S_SELECT) : mode == M_BROWSE ? s(S_SELECT) : s(S_OPEN);
            case V_DAY: return dayIdx < dayEvents().size() ? s(S_EDIT) : s(S_ADDEV);
            default: return s(S_SELECT);
        }
    }
    String softR() {
        switch (view) {
            case V_CAL: return menuOpen ? s(S_BACK) : s(S_MENU);
            case V_DAY: {
                List<EventStore.Event> ev = dayEvents();
                if (dayIdx < ev.size()) return pendingDelete == ev.get(dayIdx).id ? s(S_SURE) : s(S_DELETE);
                return s(S_BACK);
            }
            case V_EDIT: return s(S_CANCEL);
            default: return s(S_BACK);
        }
    }

    // --------------------------------------------------------------------- text
    static final int S_TODAY = 0, S_CONVERT = 1, S_SETTINGS = 2, S_G2H = 3, S_H2G = 4, S_DAY = 5, S_MONTH = 6, S_YEAR = 7,
            S_SHOW = 8, S_CONVTITLE = 9, S_SETTITLE = 10, S_LANG = 11, S_HOL = 12, S_DIA = 13, S_ISR = 14, S_UD = 15,
            S_UD0 = 16, S_UD1 = 17, S_RESULT = 18, S_MENU = 19, S_SELECT = 20, S_OPEN = 21, S_BACK = 22, S_PLUSEV = 23,
            S_ADDEV = 24, S_UPCOMING = 25, S_EDIT = 26, S_DELETE = 27, S_SURE = 28, S_SAVE = 29, S_CANCEL = 30,
            S_NOEVENTS = 31, S_TITLE = 32, S_TIME = 33, S_REMIND = 34, S_REPEAT = 35, S_ALLDAY = 36, S_ONCE = 37,
            S_YEARLY = 38, S_EVENT = 39, S_NEWEVENT = 40, S_EDITEVENT = 41, S_NONE = 42, S_AT = 43, S_NOHOL = 44,
            S_CANDLE = 45, S_NOUP = 46, S_TAP = 47, S_CHABAD = 48, S_ON = 49, S_OFF = 50, S_OMER = 51;
    private static final String[] EN = {
        "Today", "Convert dates", "Settings",
        "Gregorian → Hebrew", "Hebrew → Gregorian", "DAY", "MONTH", "YEAR", "Show in calendar", "Date Converter",
        "Settings", "Language", "Yom Tov days", "Diaspora (2 days)", "Eretz Yisroel (1 day)", "Up / Down keys", "Up = next year", "Up = previous year",
        "RESULT", "Menu", "Select", "Open", "Back", "+ Event",
        "Add event", "Upcoming events", "Edit", "Delete", "Sure?", "Save", "Cancel",
        "No events", "Title", "Time", "Reminder", "Repeat", "All day", "Once",
        "Every year (Hebrew date)", "Event", "New event", "Edit event", "None", "At time of event", "",
        "day", "Nothing coming up", "tap to type",
        "Chabad days", "On", "Off", "Omer"
    };
    private static final String[] HE = {
        "היום", "המרת תאריכים", "הגדרות",
        "לועזי → עברי", "עברי → לועזי",
        "יום", "חודש", "שנה", "הצג בלוח",
        "המרת תאריכים", "הגדרות", "שפה",
        "ימים טובים", "חו״ל (יומיים)", "ארץ ישראל (יום אחד)",
        "מקשי למעלה / למטה",
        "למעלה = שנה הבאה",
        "למעלה = שנה קודמת",
        "תוצאה", "תפריט", "בחר", "פתח",
        "חזרה", "+ אירוע",
        "הוסף אירוע", "אירועים קרובים",
        "ערוך", "מחק", "בטוח?", "שמור", "ביטול",
        "אין אירועים", "כותרת", "שעה",
        "תזכורת", "חוזר", "כל היום",
        "פעם אחת",
        "כל שנה (תאריך עברי)", "אירוע",
        "אירוע חדש", "עריכת אירוע",
        "ללא", "בזמן האירוע", "",
        "נר", "אין אירועים קרובים",
        "לחץ להקלדה",
        "ימי חב״ד", "מופעל", "כבוי", "עומר"
    };
    String s(int i) { return he ? HE[i] : EN[i]; }

    String timeLabel(int minutes) {
        if (minutes < 0) return s(S_ALLDAY);
        return (minutes / 60 < 10 ? "0" : "") + minutes / 60 + ":" + (minutes % 60 < 10 ? "0" : "") + minutes % 60;
    }
    String remindLabel(int r) {
        if (r < 0) return s(S_NONE);
        if (r == 0) return s(S_AT);
        if (he) {
            if (r < 60) return "לפני " + r + " דקות";
            if (r == 60) return "שעה לפני";
            if (r == 120) return "שעתיים לפני";
            return "יום לפני";
        }
        if (r < 60) return r + " min before";
        if (r == 60) return "1 hour before";
        if (r == 120) return "2 hours before";
        return "1 day before";
    }

    static final String[] WD_EN = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Shabbat"};
    static final String[] WD_HE = {"ראשון", "שני", "שלישי",
        "רביעי", "חמישי", "שישי", "שבת"};
    static final String[] WDS_EN = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static final String[] WDS_HE = {"א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"};
    static final String[] GM_EN = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
        "October", "November", "December"};
    static final String[] GM_HE = {"ינואר", "פברואר", "מרץ",
        "אפריל", "מאי", "יוני", "יולי",
        "אוגוסט", "ספטמבר", "אוקטובר",
        "נובמבר", "דצמבר"};
    static final String[] GMS_EN = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static final String[] GMS_HE = {"ינו׳", "פבר׳", "מרץ", "אפר׳",
        "מאי", "יוני", "יולי", "אוג׳", "ספט׳",
        "אוק׳", "נוב׳", "דצמ׳"};

    String wd(int i) { return he ? WD_HE[i] : WD_EN[i]; }
    String wdShort(int i) { return he ? WDS_HE[i] : WDS_EN[i]; }
    String gm(int m) { return he ? GM_HE[m - 1] : GM_EN[m - 1]; }
    String gms(int m) { return he ? GMS_HE[m - 1] : GMS_EN[m - 1]; }

    private static final String[][] MONTH = {
        {"Tishri", "Tishrei", "תשרי"}, {"Cheshvan", "Cheshvan", "חשוון"},
        {"Kislev", "Kislev", "כסלו"}, {"Tevet", "Tevet", "טבת"},
        {"Shevat", "Shevat", "שבט"}, {"Adar", "Adar", "אדר"},
        {"AdarI", "Adar I", "אדר א׳"}, {"AdarII", "Adar II", "אדר ב׳"},
        {"Nisan", "Nisan", "ניסן"}, {"Iyar", "Iyar", "אייר"},
        {"Sivan", "Sivan", "סיוון"}, {"Tammuz", "Tammuz", "תמוז"},
        {"Av", "Av", "אב"}, {"Elul", "Elul", "אלול"}
    };
    static String monthName(String id, boolean heb) {
        for (String[] m : MONTH) if (m[0].equals(id)) return heb ? m[2] : m[1];
        return id;
    }

    private static final String[][] HOL = {
        {"rh", "Rosh Hashana", "ראש השנה"},
        {"rh2", "Rosh Hashana II", "ראש השנה ב׳"},
        {"gedaliah", "Fast of Gedaliah", "צום גדליה"},
        {"yk", "Yom Kippur", "יום כיפור"},
        {"sukkot", "Sukkot", "סוכות"},
        {"sukkot2", "Sukkot II", "סוכות ב׳"},
        {"chm", "Chol HaMoed", "חול המועד"},
        {"hoshana", "Hoshana Rabba", "הושענא רבה"},
        {"shemini", "Shemini Atzeret", "שמיני עצרת"},
        {"shemini_st", "Shemini Atzeret / Simchat Torah", "שמיני עצרת / שמחת תורה"},
        {"simchat", "Simchat Torah", "שמחת תורה"},
        {"chanukah", "Chanukah", "חנוכה"},
        {"tevet10", "Fast of 10 Tevet", "עשרה בטבת"},
        {"tubishvat", "Tu BiShvat", "ט״ו בשבט"},
        {"purimkatan", "Purim Katan", "פורים קטן"},
        {"shushankatan", "Shushan Purim Katan", "שושן פורים קטן"},
        {"esther", "Fast of Esther", "תענית אסתר"},
        {"purim", "Purim", "פורים"},
        {"shushan", "Shushan Purim", "שושן פורים"},
        {"pesach", "Pesach", "פסח"},
        {"pesach2", "Pesach II", "פסח ב׳"},
        {"pesach7", "Pesach (7th day)", "שביעי של פסח"},
        {"pesach8", "Pesach (8th day)", "אחרון של פסח"},
        {"lag", "Lag BaOmer", "ל״ג בעומר"},
        {"shavuot", "Shavuot", "שבועות"},
        {"shavuot2", "Shavuot II", "שבועות ב׳"},
        {"tammuz17", "17 Tammuz", "י״ז בתמוז"},
        {"tisha", "Tisha B'Av", "תשעה באב"},
        {"tubav", "Tu B'Av", "ט״ו באב"},
        {"rc", "Rosh Chodesh", "ראש חודש"},
        {"erev_rh", "Erev Rosh Hashana", "ערב ראש השנה"},
        {"erev_yk", "Erev Yom Kippur", "ערב יום כיפור"},
        {"erev_sukkot", "Erev Sukkot", "ערב סוכות"},
        {"erev_pesach", "Erev Pesach", "ערב פסח"},
        {"bechorim", "Fast of the Firstborn", "תענית בכורות"},
        {"pesach_sheni", "Pesach Sheni", "פסח שני"},
        {"erev_shavuot", "Erev Shavuot", "ערב שבועות"},
        {"erev_tisha", "Erev Tisha B'Av", "ערב תשעה באב"},
        {"omer", "Omer", "עומר"},
        {"c_vav_tishrei", "Yahrzeit of Rebbetzin Chana (6 Tishrei)", "יארצייט הרבנית חנה"},
        {"c_yud_gimmel_tishrei", "Yahrzeit of the Maharash (13 Tishrei)", "יארצייט המהר״ש"},
        {"c_chof_cheshvan", "Birthday of the Rashab (20 Cheshvan)", "יום הולדת הרש״ב"},
        {"c_recovery", "Rebbe's recovery, 5738", "הבראת הרבי תשל״ח"},
        {"c_tes_kislev", "Mitteler Rebbe: birthday & yahrzeit (9 Kislev)", "הולדת והסתלקות האדמו״ר האמצעי"},
        {"c_yud_kislev", "Yud Kislev: Mitteler Rebbe's liberation", "י׳ כסלו – גאולת האדמו״ר האמצעי"},
        {"c_yud_daled_kislev", "Rebbe's wedding anniversary (14 Kislev)", "יום נישואי הרבי"},
        {"c_yud_tes_kislev", "Yud-Tes Kislev: Rosh Hashana of Chassidus", "י״ט כסלו – ראש השנה לחסידות"},
        {"c_chof_kislev", "Chof Kislev: Rosh Hashana of Chassidus (day 2)", "כ׳ כסלו – ראש השנה לחסידות"},
        {"c_hei_teves", "Hei Teves (Seforim victory)", "ה׳ טבת – הכרעת בית המשפט בספרים"},
        {"c_chof_daled_teves", "Yahrzeit of the Alter Rebbe (24 Tevet)", "יארצייט אדמו״ר הזקן"},
        {"c_yud_shevat", "Yud Shevat: Frierdiker Rebbe's yahrzeit", "י׳ שבט – יארצייט הרבי הריי״צ"},
        {"c_chof_beis_shevat", "Yahrzeit of Rebbetzin Chaya Mushka (22 Shevat)", "יארצייט הרבנית חיה מושקא"},
        {"c_chof_hei_adar", "Birthday of Rebbetzin Chaya Mushka (25 Adar)", "יום הולדת הרבנית חיה מושקא"},
        {"c_beis_nissan", "Yahrzeit of the Rashab (2 Nissan)", "יארצייט הרש״ב"},
        {"c_yud_alef_nissan", "Rebbe's birthday (11 Nissan)", "יום הולדת הרבי"},
        {"c_yud_gimmel_nissan", "Yahrzeit of the Tzemach Tzedek (13 Nissan)", "יארצייט הצמח צדק"},
        {"c_beis_iyar", "Birthday of the Maharash (2 Iyar)", "יום הולדת המהר״ש"},
        {"c_gimmel_tammuz", "Gimmel Tammuz: Rebbe's yahrzeit", "גימל תמוז – יארצייט הרבי"},
        {"c_yud_beis_tammuz", "Chag HaGeula: 12 Tammuz", "חג הגאולה י״ב תמוז"},
        {"c_yud_gimmel_tammuz", "Chag HaGeula: 13 Tammuz", "חג הגאולה י״ג תמוז"},
        {"c_baal_shem_tov", "Yahrzeit of the Baal Shem Tov", "יארצייט הבעל שם טוב"},
        {"c_chof_av", "Yahrzeit of the Rebbe's father, R' Levi Yitzchok (20 Av)", "יארצייט ר׳ לוי יצחק"},
        {"c_tes_vav_elul", "Tes-Vav Elul: Tomchei Tmimim founded", "ט״ו אלול – יסוד תומכי תמימים"},
        {"c_chai_elul", "Chai Elul", "חי אלול"},
        {"c_tzemach_birth", "Birthday of the Tzemach Tzedek (29 Elul)", "יום הולדת הצמח צדק"}
    };
    String holName(HebCal.Hol h) {
        String n = h.k;
        for (String[] x : HOL) if (x[0].equals(h.k)) { n = he ? x[2] : x[1]; break; }
        if (h.t.equals("omer")) return s(S_OMER) + " " + (he ? HebCal.gematria(h.n) : String.valueOf(h.n));
        if (h.n > 0) n = n + " · " + s(S_CANDLE) + " " + (he ? HebCal.gematria(h.n) : String.valueOf(h.n));
        return n;
    }
    String holidayLine(int y, String id, int d, int wd) {
        StringBuilder b = new StringBuilder();
        for (HebCal.Hol h : holidays(y, id, d, wd)) { if (b.length() > 0) b.append("  ·  "); b.append(holName(h)); }
        return b.toString();
    }

    String dayLabel(int d) { return he ? HebCal.gematria(d) : String.valueOf(d); }
    String hebStr(int y, String id, int d, boolean heb) {
        if (heb) return HebCal.gematria(d) + " " + monthName(id, true) + " " + HebCal.gematria(y % 1000);
        return d + " " + monthName(id, false) + " " + y;
    }
    String gregStr(HebCal.GDate g, int wd) {
        if (he) return "יום " + WD_HE[wd] + ", " + g.d + " ב" + GM_HE[g.m - 1] + " " + g.y;
        return WD_EN[wd] + ", " + g.d + " " + GM_EN[g.m - 1] + " " + g.y;
    }
    /** Short form for lists, e.g. "Wed 4 Nov". */
    String gregShort(HebCal.GDate g, int wd) { return wdShort(wd) + " " + g.d + " " + gms(g.m); }
    List<HebCal.Hol> holidays(int y, String id, int d, int wd) { return HebCal.holidays(y, id, d, wd, israel, chabad); }
}
