package com.example.hebrewcalendar;

import java.util.ArrayList;
import java.util.List;

/** Hebrew calendar engine. Pure Java, no Android classes. RD = fixed day number (RD 0 is a Sunday). */
final class HebCal {
    static final int EPOCH = -1373427; // RD of 1 Tishri, AM 1

    static final class Month {
        final String id; final int len;
        Month(String id, int len) { this.id = id; this.len = len; }
    }
    static final class HDate { int y; String id; int mi; int d; }
    static final class GDate { int y; int m; int d; }
    static final class Hol {
        final String k; final String t; final int n;
        Hol(String k, String t, int n) { this.k = k; this.t = t; this.n = n; }
    }

    private HebCal() {}

    static int mod(int a, int b) { int r = a % b; return r < 0 ? r + b : r; }
    static long fdiv(long a, long b) { long q = a / b; if ((a % b != 0) && ((a < 0) != (b < 0))) q--; return q; }

    static boolean isLeap(int y) { return mod(7 * y + 1, 19) < 7; }

    static int elapsed(int y) {
        long m = fdiv(235L * y - 234, 19);
        long parts = 12084L + 13753L * m;
        long day = m * 29 + fdiv(parts, 25920);
        if (mod((int) ((3 * (day + 1)) % 7), 7) < 3) day++;
        return (int) day;
    }
    static int correction(int y) {
        int a = elapsed(y - 1), b = elapsed(y), c = elapsed(y + 1);
        if (c - b == 356) return 2;
        if (b - a == 382) return 1;
        return 0;
    }
    static int newYear(int y) { return EPOCH + elapsed(y) + correction(y); }
    static int yearLength(int y) { return newYear(y + 1) - newYear(y); }

    static Month[] monthsOf(int y) {
        int len = yearLength(y) % 10;
        List<Month> m = new ArrayList<Month>();
        m.add(new Month("Tishri", 30));
        m.add(new Month("Cheshvan", len == 5 ? 30 : 29));
        m.add(new Month("Kislev", len == 3 ? 29 : 30));
        m.add(new Month("Tevet", 29));
        m.add(new Month("Shevat", 30));
        if (isLeap(y)) { m.add(new Month("AdarI", 30)); m.add(new Month("AdarII", 29)); }
        else m.add(new Month("Adar", 29));
        m.add(new Month("Nisan", 30)); m.add(new Month("Iyar", 29)); m.add(new Month("Sivan", 30));
        m.add(new Month("Tammuz", 29)); m.add(new Month("Av", 30)); m.add(new Month("Elul", 29));
        return m.toArray(new Month[0]);
    }
    static int monthIdx(Month[] ms, String id) {
        for (int i = 0; i < ms.length; i++) if (ms[i].id.equals(id)) return i;
        return 0;
    }
    static int monthLen(int y, String id) { Month[] ms = monthsOf(y); return ms[monthIdx(ms, id)].len; }

    static int hebToRD(int y, String id, int d) {
        Month[] ms = monthsOf(y);
        int rd = newYear(y);
        for (Month m : ms) {
            if (m.id.equals(id)) return rd + d - 1;
            rd += m.len;
        }
        return rd;
    }

    static HDate rdToHeb(int rd) {
        int y = (int) Math.floor((rd - EPOCH) / 365.24682) + 1;
        while (newYear(y) > rd) y--;
        while (newYear(y + 1) <= rd) y++;
        Month[] ms = monthsOf(y);
        int left = rd - newYear(y);
        HDate h = new HDate();
        h.y = y;
        for (int i = 0; i < ms.length; i++) {
            if (left < ms[i].len) { h.id = ms[i].id; h.mi = i; h.d = left + 1; return h; }
            left -= ms[i].len;
        }
        return h;
    }

    static boolean isGregLeap(int y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }
    static int gregDays(int y, int m) {
        int[] d = {31, isGregLeap(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        return d[m - 1];
    }
    static int gregToRD(int y, int m, int d) {
        int p = y - 1;
        int r = 365 * p + p / 4 - p / 100 + p / 400 + (367 * m - 362) / 12 + d;
        if (m > 2) r -= isGregLeap(y) ? 1 : 2;
        return r;
    }
    static GDate rdToGreg(int rd) {
        int d0 = rd - 1;
        int n400 = (int) fdiv(d0, 146097), d1 = mod(d0, 146097);
        int n100 = d1 / 36524, d2 = d1 % 36524;
        int n4 = d2 / 1461, d3 = d2 % 1461;
        int n1 = d3 / 365;
        int y = 400 * n400 + 100 * n100 + 4 * n4 + n1;
        if (n100 != 4 && n1 != 4) y++;
        int corr = rd < gregToRD(y, 3, 1) ? 0 : (isGregLeap(y) ? 1 : 2);
        int m = (12 * (rd - gregToRD(y, 1, 1) + corr) + 373) / 367;
        GDate g = new GDate();
        g.y = y; g.m = m; g.d = rd - gregToRD(y, m, 1) + 1;
        return g;
    }
    static int dow(int rd) { return mod(rd, 7); } // 0 = Sunday ... 6 = Shabbat

    /** Hebrew numerals: 24 -> כ״ד, 787 -> תשפ״ז */
    static String gematria(int n) {
        String[] ones = {"", "א", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט"};
        String[] tens = {"", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ"};
        String[] hund = {"", "ק", "ר", "ש", "ת"};
        StringBuilder s = new StringBuilder();
        int h = n / 100;
        n = n % 100;
        while (h > 4) { s.append("ת"); h -= 4; }
        s.append(hund[h]);
        if (n == 15) s.append("טו");
        else if (n == 16) s.append("טז");
        else s.append(tens[n / 10]).append(ones[n % 10]);
        String r = s.toString();
        if (r.length() == 1) return r + "׳";
        return r.substring(0, r.length() - 1) + "״" + r.substring(r.length() - 1);
    }

    /** Holidays for a Hebrew date. wd = weekday (0 = Sunday). */
    static List<Hol> holidays(int y, String id, int d, int wd, boolean israel) {
        List<Hol> out = new ArrayList<Hol>();
        switch (id) {
            case "Tishri":
                if (d == 1) out.add(new Hol("rh", "major", 0));
                if (d == 2) out.add(new Hol("rh2", "major", 0));
                if ((d == 3 && wd != 6) || (d == 4 && wd == 0)) out.add(new Hol("gedaliah", "fast", 0));
                if (d == 10) out.add(new Hol("yk", "major", 0));
                if (d == 15) out.add(new Hol("sukkot", "major", 0));
                if (d == 16) out.add(israel ? new Hol("chm", "minor", 0) : new Hol("sukkot2", "major", 0));
                if (d >= 17 && d <= 20) out.add(new Hol("chm", "minor", 0));
                if (d == 21) out.add(new Hol("hoshana", "minor", 0));
                if (d == 22) out.add(new Hol(israel ? "shemini_st" : "shemini", "major", 0));
                if (d == 23 && !israel) out.add(new Hol("simchat", "major", 0));
                break;
            case "Kislev":
                if (d >= 25) out.add(new Hol("chanukah", "minor", d - 24));
                break;
            case "Tevet": {
                int kislev = monthsOf(y)[2].len;
                if (d <= 32 - kislev) out.add(new Hol("chanukah", "minor", kislev - 24 + d));
                if (d == 10) out.add(new Hol("tevet10", "fast", 0));
                break;
            }
            case "Shevat":
                if (d == 15) out.add(new Hol("tubishvat", "minor", 0));
                break;
            case "AdarI":
                if (d == 14) out.add(new Hol("purimkatan", "minor", 0));
                if (d == 15) out.add(new Hol("shushankatan", "minor", 0));
                break;
            case "Adar":
            case "AdarII":
                if ((d == 13 && wd != 6) || (d == 11 && wd == 4)) out.add(new Hol("esther", "fast", 0));
                if (d == 14) out.add(new Hol("purim", "minor", 0));
                if (d == 15) out.add(new Hol("shushan", "minor", 0));
                break;
            case "Nisan":
                if (d == 15) out.add(new Hol("pesach", "major", 0));
                if (d == 16) out.add(israel ? new Hol("chm", "minor", 0) : new Hol("pesach2", "major", 0));
                if (d >= 17 && d <= 20) out.add(new Hol("chm", "minor", 0));
                if (d == 21) out.add(new Hol("pesach7", "major", 0));
                if (d == 22 && !israel) out.add(new Hol("pesach8", "major", 0));
                break;
            case "Iyar":
                if (d == 18) out.add(new Hol("lag", "minor", 0));
                break;
            case "Sivan":
                if (d == 6) out.add(new Hol("shavuot", "major", 0));
                if (d == 7 && !israel) out.add(new Hol("shavuot2", "major", 0));
                break;
            case "Tammuz":
                if ((d == 17 && wd != 6) || (d == 18 && wd == 0)) out.add(new Hol("tammuz17", "fast", 0));
                break;
            case "Av":
                if ((d == 9 && wd != 6) || (d == 10 && wd == 0)) out.add(new Hol("tisha", "fast", 0));
                if (d == 15) out.add(new Hol("tubav", "minor", 0));
                break;
            default:
                break;
        }
        if ((d == 1 && !id.equals("Tishri")) || d == 30) out.add(new Hol("rc", "rc", 0));
        return out;
    }
}
