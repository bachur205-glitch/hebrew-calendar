package com.example.hebrewcalendar;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;

/** Storage of events plus alarm scheduling and notifications. */
final class Reminders {
    static final String CHANNEL = "events";
    static final String ACTION = "com.example.hebrewcalendar.REMIND";

    private Reminders() {}

    // ---------------------------------------------------------------- storage
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("hebcal", Context.MODE_PRIVATE); }

    static EventStore load(Context c) {
        EventStore s = new EventStore();
        s.decode(prefs(c).getString("events", ""));
        return s;
    }
    static void save(Context c, EventStore s) {
        prefs(c).edit().putString("events", s.encode()).apply();
    }

    static int todayRD() {
        Calendar c = Calendar.getInstance();
        return HebCal.gregToRD(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    // ------------------------------------------------------------------ alarms
    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Event reminders", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
        }
    }

    private static int flagImmutable() { return Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0; }

    private static Intent alarmIntent(Context c, long id) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction(ACTION);
        i.setData(Uri.parse("hebcal://event/" + id)); // makes each event's alarm distinct
        return i;
    }
    private static int reqCode(long id) { return (int) (id & 0x7fffffff); }

    static void cancel(Context c, long id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, reqCode(id), alarmIntent(c, id), PendingIntent.FLAG_NO_CREATE | flagImmutable());
        if (pi != null) { am.cancel(pi); pi.cancel(); }
    }

    static void schedule(Context c, EventStore store, EventStore.Event e) {
        cancel(c, e.id);
        EventStore.Trigger t = store.nextTrigger(e, todayRD(), System.currentTimeMillis());
        if (t == null) return;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = alarmIntent(c, e.id);
        i.putExtra("rd", t.rd);
        PendingIntent pi = PendingIntent.getBroadcast(c, reqCode(e.id), i, PendingIntent.FLAG_UPDATE_CURRENT | flagImmutable());
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.at, pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, t.at, pi);
        } catch (SecurityException ex) {
            am.set(AlarmManager.RTC_WAKEUP, t.at, pi);
        }
    }

    static void rescheduleAll(Context c, EventStore store) {
        for (EventStore.Event e : store.list) schedule(c, store, e);
    }

    // ------------------------------------------------------------ notification
    static void notifyEvent(Context c, EventStore.Event e, int occRd) {
        ensureChannel(c);
        boolean he = prefs(c).getBoolean("he", false);
        HebCal.GDate g = HebCal.rdToGreg(occRd);
        HebCal.HDate h = HebCal.rdToHeb(occRd);
        String when = e.minutes < 0 ? (he ? "כל היום" : "All day")
                : (e.minutes / 60 < 10 ? "0" : "") + e.minutes / 60 + ":" + (e.minutes % 60 < 10 ? "0" : "") + e.minutes % 60;
        String date = he
                ? HebCal.gematria(h.d) + " " + Model.monthName(h.id, true) + " · " + g.d + " " + Model.GMS_HE[g.m - 1]
                : g.d + " " + Model.GMS_EN[g.m - 1] + " · " + h.d + " " + Model.monthName(h.id, false);
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("rd", occRd);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, reqCode(e.id), open, PendingIntent.FLAG_UPDATE_CURRENT | flagImmutable());
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notify)
         .setContentTitle(e.title)
         .setContentText(when + " · " + date)
         .setAutoCancel(true)
         .setContentIntent(pi);
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
            b.setDefaults(Notification.DEFAULT_ALL);
        }
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(reqCode(e.id), b.build());
    }
}
