package com.example.hebrewcalendar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Events and reminders. Pure Java (no Android classes) so it can be tested anywhere. */
final class EventStore {

    static final class Event {
        long id;                 // 0 = not saved yet
        int rd;                  // day of the (first) occurrence
        int minutes = -1;        // minutes after midnight, -1 = all day
        int remind = -1;         // minutes before, -1 = no reminder
        boolean yearly;          // repeat every year on the same HEBREW date
        String hid = "";         // Hebrew month id of rd
        int hd;                  // Hebrew day of rd
        String title = "";

        Event copy() {
            Event e = new Event();
            e.id = id; e.rd = rd; e.minutes = minutes; e.remind = remind; e.yearly = yearly;
            e.hid = hid; e.hd = hd; e.title = title;
            return e;
        }
    }

    static final class Trigger {
        final long at; final int rd;
        Trigger(long at, int rd) { this.at = at; this.rd = rd; }
    }

    /** Reminder choices, in minutes before the event. */
    static final int[] REMIND = {-1, 0, 5, 10, 15, 30, 60, 120, 1440};

    final List<Event> list = new ArrayList<Event>();
    Runnable onChange;
    private long nextId = 1;

    private static final Comparator<Event> BY_TIME = new Comparator<Event>() {
        @Override public int compare(Event a, Event b) {
            if (a.minutes != b.minutes) return a.minutes < b.minutes ? -1 : 1; // all day (-1) first
            return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
        }
    };

    private void changed() { if (onChange != null) onChange.run(); }

    private static void fillHeb(Event e) {
        HebCal.HDate h = HebCal.rdToHeb(e.rd);
        e.hid = h.id; e.hd = h.d;
    }

    Event create(int rd) {
        Event e = new Event();
        e.rd = rd;
        fillHeb(e);
        return e;
    }

    Event find(long id) {
        for (Event e : list) if (e.id == id) return e;
        return null;
    }

    void save(Event e) {
        fillHeb(e);
        if (e.id == 0) e.id = nextId++;
        Event copy = e.copy();
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == e.id) { list.set(i, copy); replaced = true; break; }
        }
        if (!replaced) list.add(copy);
        changed();
    }

    void delete(long id) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == id) { list.remove(i); break; }
        }
        changed();
    }

    private static boolean sameMonth(String a, String b) {
        if (a.equals(b)) return true;
        return (a.equals("Adar") && b.equals("AdarII")) || (a.equals("AdarII") && b.equals("Adar"));
    }

    boolean occursOn(Event e, int rd) {
        if (!e.yearly) return e.rd == rd;
        if (rd < e.rd) return false;
        HebCal.HDate h = HebCal.rdToHeb(rd);
        return h.d == e.hd && sameMonth(e.hid, h.id);
    }

    /** Events happening on a day, all-day first, then by time. */
    List<Event> on(int rd) {
        List<Event> out = new ArrayList<Event>();
        for (Event e : list) if (occursOn(e, rd)) out.add(e);
        Collections.sort(out, BY_TIME);
        return out;
    }

    boolean any(int rd) {
        for (Event e : list) if (occursOn(e, rd)) return true;
        return false;
    }

    // ------------------------------------------------------------------ reminders
    /** Wall-clock time (ms) at which the reminder for the occurrence on occRd should fire. All-day events use 09:00. */
    static long triggerAt(Event e, int occRd) {
        HebCal.GDate g = HebCal.rdToGreg(occRd);
        int base = e.minutes < 0 ? 9 * 60 : e.minutes;
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(g.y, g.m - 1, g.d, base / 60, base % 60, 0);
        return c.getTimeInMillis() - e.remind * 60000L;
    }

    /** The next reminder after nowMs, or null. Looks about a year ahead for yearly events. */
    Trigger nextTrigger(Event e, int todayRd, long nowMs) {
        if (e.remind < 0) return null;
        if (!e.yearly) {
            long at = triggerAt(e, e.rd);
            return at > nowMs ? new Trigger(at, e.rd) : null;
        }
        for (int d = todayRd; d <= todayRd + 400; d++) {
            if (occursOn(e, d)) {
                long at = triggerAt(e, d);
                if (at > nowMs) return new Trigger(at, d);
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- persistence
    private static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\') b.append("\\\\");
            else if (c == '|') b.append("\\p");
            else if (c == '\n') b.append("\\n");
            else if (c == '\r') { /* drop */ }
            else b.append(c);
        }
        return b.toString();
    }
    private static String unesc(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                b.append(n == 'p' ? '|' : n == 'n' ? '\n' : n);
            } else b.append(c);
        }
        return b.toString();
    }

    String encode() {
        StringBuilder b = new StringBuilder();
        for (Event e : list) {
            b.append(e.id).append('|').append(e.rd).append('|').append(e.minutes).append('|').append(e.remind).append('|')
             .append(e.yearly ? 1 : 0).append('|').append(e.hid).append('|').append(e.hd).append('|').append(esc(e.title)).append('\n');
        }
        return b.toString();
    }

    void decode(String s) {
        list.clear();
        nextId = 1;
        if (s == null) return;
        for (String line : s.split("\n")) {
            if (line.length() == 0) continue;
            String[] p = line.split("\\|", -1);
            if (p.length < 8) continue;
            try {
                Event e = new Event();
                e.id = Long.parseLong(p[0]); e.rd = Integer.parseInt(p[1]); e.minutes = Integer.parseInt(p[2]);
                e.remind = Integer.parseInt(p[3]); e.yearly = p[4].equals("1"); e.hid = p[5];
                e.hd = Integer.parseInt(p[6]); e.title = unesc(p[7]);
                list.add(e);
                if (e.id >= nextId) nextId = e.id + 1;
            } catch (NumberFormatException ex) {
                // skip a damaged line
            }
        }
    }
}
